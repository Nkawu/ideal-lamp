# Kubernetes Monitoring Stack

This directory contains Kubernetes configuration files for monitoring a 3-node MicroK8s cluster using Prometheus and Grafana.

## Prerequisites

1. Enable required MicroK8s addons:
```bash
microk8s enable dns
microk8s enable ingress
```

## Deployment

Deploy all components in order:

```bash
kubectl apply -f 00-namespace.yaml
kubectl apply -f 01-rbac.yaml
kubectl apply -f 02-prometheus-config.yaml
kubectl apply -f 03-prometheus-deployment.yaml
kubectl apply -f 04-grafana-config.yaml
kubectl apply -f 05-grafana-deployment.yaml
kubectl apply -f 06-services.yaml
kubectl apply -f 07-ingress.yaml
```

Or deploy everything at once:

```bash
kubectl apply -f .
```

## Verify Deployment

Check that all pods are running:

```bash
kubectl get pods -n monitoring
```

Check services:

```bash
kubectl get svc -n monitoring
```

Check ingress:

```bash
kubectl get ingress -n monitoring
```

## Accessing the Dashboards

### Option 1: Using Hostname (Recommended)

1. Get the ingress controller IP:
```bash
kubectl get ingress -n monitoring
```

2. Add to `/etc/hosts` on your remote desktops:
```
<INGRESS_IP> monitoring.local
```

3. Access dashboards:
   - Grafana: http://monitoring.local/grafana
   - Prometheus: http://monitoring.local/prometheus

### Option 2: Using IP Address Directly

If you prefer to access via IP without hostname, modify 07-ingress.yaml to remove the `host` field or use the default backend.

## Default Credentials

- **Grafana**
  - Username: `admin`
  - Password: `admin`
  - Change password on first login

## Configuration Details

### Prometheus

- Scrapes metrics from:
  - Kubernetes API servers
  - Kubernetes nodes
  - cAdvisor (container metrics)
  - Pods with annotation `prometheus.io/scrape: "true"`
  - Service endpoints with annotation `prometheus.io/scrape: "true"`

### Grafana

- Pre-configured with Prometheus as data source
- Accessible via ingress at `/grafana` path
- Default admin credentials (change after first login)

### Resource Limits

Current configuration:
- **Prometheus**: 512Mi-2Gi memory, 0.5-1 CPU
- **Grafana**: 256Mi-512Mi memory, 0.25-0.5 CPU

Adjust these in the deployment files based on your cluster resources.

## Adding More Exporters

To monitor additional metrics, you can deploy exporters like:
- `node-exporter` for detailed node metrics
- `kube-state-metrics` for Kubernetes object metrics

## Troubleshooting

Check pod logs:
```bash
kubectl logs -n monitoring <pod-name>
```

Check ingress controller logs:
```bash
kubectl logs -n ingress <ingress-controller-pod>
```

Verify RBAC permissions:
```bash
kubectl auth can-i list nodes --as=system:serviceaccount:monitoring:prometheus
```

## Storage Persistence

Current configuration uses `emptyDir` for storage, which means data is lost on pod restart. For production use, configure persistent volumes in:
- 03-prometheus-deployment.yaml
- 05-grafana-deployment.yaml
