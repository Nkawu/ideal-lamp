# Monitoring Chart

A Helm chart for deploying Prometheus and Grafana monitoring stack on Kubernetes.

## Prerequisites

- Kubernetes 1.19+
- Helm 3.0+
- Ingress controller (nginx recommended for MicroK8s)

## Installing the Chart

### Enable MicroK8s Addons (if using MicroK8s)

```bash
microk8s enable dns
microk8s enable ingress
```

### Install the Chart

```bash
# Install with default values
helm install monitoring ./monitoring-chart

# Install with custom values
helm install monitoring ./monitoring-chart --values custom-values.yaml

# Install with inline overrides
helm install monitoring ./monitoring-chart \
  --set grafana.adminPassword=securepassword \
  --set ingress.host=monitoring.example.com
```

## Uninstalling the Chart

```bash
helm uninstall monitoring
```

This removes all the Kubernetes components associated with the chart and deletes the release.

## Configuration

The following table lists the configurable parameters of the monitoring chart and their default values.

### Global Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `namespace.create` | Create namespace | `true` |
| `namespace.name` | Namespace name | `monitoring` |

### Prometheus Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `prometheus.enabled` | Enable Prometheus | `true` |
| `prometheus.image.repository` | Prometheus image repository | `prom/prometheus` |
| `prometheus.image.tag` | Prometheus image tag | `latest` |
| `prometheus.image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `prometheus.replicas` | Number of replicas | `1` |
| `prometheus.service.type` | Service type | `ClusterIP` |
| `prometheus.service.port` | Service port | `9090` |
| `prometheus.scrapeInterval` | Scrape interval | `15s` |
| `prometheus.evaluationInterval` | Evaluation interval | `15s` |
| `prometheus.storage.type` | Storage type (emptyDir or persistentVolumeClaim) | `emptyDir` |
| `prometheus.resources.requests.memory` | Memory request | `512Mi` |
| `prometheus.resources.requests.cpu` | CPU request | `500m` |
| `prometheus.resources.limits.memory` | Memory limit | `2Gi` |
| `prometheus.resources.limits.cpu` | CPU limit | `1000m` |

### Grafana Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `grafana.enabled` | Enable Grafana | `true` |
| `grafana.image.repository` | Grafana image repository | `grafana/grafana` |
| `grafana.image.tag` | Grafana image tag | `latest` |
| `grafana.image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `grafana.replicas` | Number of replicas | `1` |
| `grafana.adminUser` | Admin username | `admin` |
| `grafana.adminPassword` | Admin password | `admin` |
| `grafana.service.type` | Service type | `ClusterIP` |
| `grafana.service.port` | Service port | `3000` |
| `grafana.storage.type` | Storage type (emptyDir or persistentVolumeClaim) | `emptyDir` |
| `grafana.resources.requests.memory` | Memory request | `256Mi` |
| `grafana.resources.requests.cpu` | CPU request | `250m` |
| `grafana.resources.limits.memory` | Memory limit | `512Mi` |
| `grafana.resources.limits.cpu` | CPU limit | `500m` |

### Ingress Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `ingress.enabled` | Enable ingress | `true` |
| `ingress.className` | Ingress class name | `nginx` |
| `ingress.host` | Ingress hostname | `monitoring.local` |
| `ingress.paths.prometheus` | Prometheus path | `/prometheus(/\|$)(.*)` |
| `ingress.paths.grafana` | Grafana path | `/grafana(/\|$)(.*)` |
| `ingress.tls.enabled` | Enable TLS | `false` |

### RBAC Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `rbac.create` | Create RBAC resources | `true` |
| `rbac.serviceAccountName` | Service account name | `prometheus` |

## Example Custom Values

Create a `custom-values.yaml` file:

```yaml
namespace:
  name: monitoring-prod

prometheus:
  image:
    tag: v2.45.0
  resources:
    limits:
      memory: "4Gi"
      cpu: "2000m"
  storage:
    type: persistentVolumeClaim
    persistentVolumeClaim:
      storageClass: "fast-ssd"
      size: 20Gi

grafana:
  adminPassword: "MySecurePassword123!"
  image:
    tag: 10.0.0
  storage:
    type: persistentVolumeClaim
    persistentVolumeClaim:
      storageClass: "fast-ssd"
      size: 10Gi

ingress:
  host: monitoring.example.com
  tls:
    enabled: true
    secretName: monitoring-tls
    hosts:
      - monitoring.example.com
```

Then install:

```bash
helm install monitoring ./monitoring-chart -f custom-values.yaml
```

## Upgrading the Chart

```bash
# Upgrade with new values
helm upgrade monitoring ./monitoring-chart -f custom-values.yaml

# Upgrade with inline overrides
helm upgrade monitoring ./monitoring-chart --set grafana.adminPassword=newpassword
```

## Accessing the Dashboards

After installation:

1. Get the ingress IP:
   ```bash
   kubectl get ingress -n monitoring
   ```

2. Add to `/etc/hosts` on remote desktops:
   ```
   <INGRESS_IP> monitoring.local
   ```

3. Access dashboards:
   - Grafana: http://monitoring.local/grafana
   - Prometheus: http://monitoring.local/prometheus

## Using Persistent Storage

For production use, configure persistent volumes:

```yaml
prometheus:
  storage:
    type: persistentVolumeClaim
    persistentVolumeClaim:
      storageClass: "your-storage-class"
      size: 20Gi

grafana:
  storage:
    type: persistentVolumeClaim
    persistentVolumeClaim:
      storageClass: "your-storage-class"
      size: 10Gi
```

## Disabling Components

To disable Prometheus or Grafana:

```bash
# Install without Prometheus
helm install monitoring ./monitoring-chart --set prometheus.enabled=false

# Install without Grafana
helm install monitoring ./monitoring-chart --set grafana.enabled=false
```

## Troubleshooting

### Check deployment status
```bash
helm status monitoring
kubectl get pods -n monitoring
```

### View logs
```bash
kubectl logs -n monitoring deployment/prometheus
kubectl logs -n monitoring deployment/grafana
```

### Check ingress
```bash
kubectl describe ingress -n monitoring
```

## License

This chart is provided as-is for monitoring Kubernetes clusters.
