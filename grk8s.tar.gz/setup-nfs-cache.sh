#!/bin/bash
# GitLab Runner NFS Cache Setup Script for MicroK8s
# This script automates the setup of NFS storage and GitLab Runner with shared cache

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if MicroK8s is installed
check_microk8s() {
    print_info "Checking MicroK8s installation..."
    if ! command -v microk8s &> /dev/null; then
        print_error "MicroK8s is not installed. Please install it first."
        exit 1
    fi
    print_info "MicroK8s is installed"
}

# Check if Helm is installed
check_helm() {
    print_info "Checking Helm installation..."
    if ! command -v helm &> /dev/null; then
        print_error "Helm is not installed. Please install it first."
        exit 1
    fi
    HELM_VERSION=$(helm version --short)
    print_info "Helm is installed: $HELM_VERSION"
}

# Enable NFS addon
enable_nfs() {
    print_info "Checking NFS addon status..."

    # Check if community repo is enabled
    if ! microk8s status | grep -q "community: enabled"; then
        print_info "Enabling community repository..."
        microk8s enable community
    else
        print_info "Community repository already enabled"
    fi

    # Check if NFS is enabled
    if ! microk8s status | grep -q "nfs: enabled"; then
        print_info "Enabling NFS addon..."
        microk8s enable nfs

        # Wait for NFS server to be ready
        print_info "Waiting for NFS server to be ready..."
        sleep 10
        microk8s kubectl wait --for=condition=ready pod -l app=nfs-server-provisioner -n nfs-server-provisioner --timeout=120s || true
    else
        print_info "NFS addon already enabled"
    fi

    # Verify NFS storage class
    print_info "Verifying NFS storage class..."
    if microk8s kubectl get storageclass nfs-csi &> /dev/null; then
        print_info "NFS storage class 'nfs-csi' is available"
    else
        print_error "NFS storage class 'nfs-csi' not found"
        exit 1
    fi
}

# Create namespace
create_namespace() {
    NAMESPACE=${1:-default}

    if [ "$NAMESPACE" != "default" ]; then
        print_info "Checking namespace '$NAMESPACE'..."
        if ! microk8s kubectl get namespace "$NAMESPACE" &> /dev/null; then
            print_info "Creating namespace '$NAMESPACE'..."
            microk8s kubectl create namespace "$NAMESPACE"
        else
            print_info "Namespace '$NAMESPACE' already exists"
        fi
    fi
}

# Deploy PVC
deploy_pvc() {
    NAMESPACE=${1:-default}

    print_info "Deploying GitLab Runner cache PVC..."

    # Update namespace in PVC file if needed
    if [ "$NAMESPACE" != "default" ]; then
        print_info "Updating namespace in PVC manifest to '$NAMESPACE'..."
        sed -i.bak "s/namespace: default/namespace: $NAMESPACE/" gitlab-runner-cache-pvc.yaml
    fi

    # Apply PVC
    microk8s kubectl apply -f gitlab-runner-cache-pvc.yaml

    # Wait for PVC to be bound
    print_info "Waiting for PVC to be bound..."
    for i in {1..30}; do
        STATUS=$(microk8s kubectl get pvc gitlab-runner-cache -n "$NAMESPACE" -o jsonpath='{.status.phase}' 2>/dev/null || echo "")
        if [ "$STATUS" = "Bound" ]; then
            print_info "PVC is bound successfully"
            microk8s kubectl get pvc gitlab-runner-cache -n "$NAMESPACE"
            return 0
        fi
        echo -n "."
        sleep 2
    done

    print_error "PVC failed to bind within timeout"
    microk8s kubectl describe pvc gitlab-runner-cache -n "$NAMESPACE"
    exit 1
}

# Add GitLab Helm repo
add_helm_repo() {
    print_info "Adding GitLab Helm repository..."

    if helm repo list | grep -q "^gitlab"; then
        print_info "GitLab repo already added, updating..."
        helm repo update gitlab
    else
        helm repo add gitlab https://charts.gitlab.io
        helm repo update
    fi
}

# Verify values.yaml configuration
verify_values() {
    print_info "Verifying values.yaml configuration..."

    if [ ! -f "values.yaml" ]; then
        print_error "values.yaml not found in current directory"
        exit 1
    fi

    # Check if GitLab URL is set
    if grep -q "gitlabUrl: https://gitlab.example.com/" values.yaml; then
        print_warning "GitLab URL is still set to example.com"
        print_warning "Please update 'gitlabUrl' in values.yaml before installing"
    fi

    # Check if registration token is set
    if grep -q "runnerRegistrationToken: \"YOUR_REGISTRATION_TOKEN_HERE\"" values.yaml; then
        print_warning "Runner registration token is not set"
        print_warning "Please update 'runnerRegistrationToken' in values.yaml before installing"
    fi
}

# Install GitLab Runner
install_runner() {
    NAMESPACE=${1:-default}
    RELEASE_NAME=${2:-gitlab-runner}

    print_info "Installing GitLab Runner..."

    if [ "$NAMESPACE" = "default" ]; then
        helm install "$RELEASE_NAME" gitlab/gitlab-runner \
            --version 0.82.0 \
            -f values.yaml
    else
        helm install "$RELEASE_NAME" gitlab/gitlab-runner \
            --version 0.82.0 \
            --namespace "$NAMESPACE" \
            -f values.yaml
    fi

    print_info "Waiting for runner pod to be ready..."
    sleep 5
    microk8s kubectl wait --for=condition=ready pod -l app=gitlab-runner -n "$NAMESPACE" --timeout=120s || true

    print_info "GitLab Runner installation completed"
    microk8s kubectl get pods -n "$NAMESPACE" -l app=gitlab-runner
}

# Show status
show_status() {
    NAMESPACE=${1:-default}

    echo ""
    print_info "====== Deployment Status ======"

    echo ""
    print_info "NFS Server:"
    microk8s kubectl get pods -n nfs-server-provisioner

    echo ""
    print_info "Storage Classes:"
    microk8s kubectl get storageclass

    echo ""
    print_info "PVC:"
    microk8s kubectl get pvc -n "$NAMESPACE"

    echo ""
    print_info "PV:"
    microk8s kubectl get pv

    echo ""
    print_info "GitLab Runner:"
    microk8s kubectl get pods -n "$NAMESPACE" -l app=gitlab-runner

    echo ""
    print_info "Runner Logs (last 20 lines):"
    POD=$(microk8s kubectl get pods -n "$NAMESPACE" -l app=gitlab-runner -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
    if [ -n "$POD" ]; then
        microk8s kubectl logs -n "$NAMESPACE" "$POD" --tail=20
    else
        print_warning "No runner pod found"
    fi

    echo ""
    print_info "====== Next Steps ======"
    echo "1. Verify runner is registered in GitLab: Settings > CI/CD > Runners"
    echo "2. Copy .gitlab-ci.yml to your repository"
    echo "3. Push code to trigger a pipeline"
    echo "4. Monitor cache usage: microk8s kubectl exec -it <job-pod> -- ls -lh /cache/"
}

# Main script
main() {
    echo "=========================================="
    echo "GitLab Runner NFS Cache Setup for MicroK8s"
    echo "=========================================="
    echo ""

    # Parse arguments
    NAMESPACE="default"
    RELEASE_NAME="gitlab-runner"
    SKIP_INSTALL=false

    while [[ $# -gt 0 ]]; do
        case $1 in
            -n|--namespace)
                NAMESPACE="$2"
                shift 2
                ;;
            -r|--release)
                RELEASE_NAME="$2"
                shift 2
                ;;
            --nfs-only)
                SKIP_INSTALL=true
                shift
                ;;
            -h|--help)
                echo "Usage: $0 [OPTIONS]"
                echo ""
                echo "Options:"
                echo "  -n, --namespace NAME    Kubernetes namespace (default: default)"
                echo "  -r, --release NAME      Helm release name (default: gitlab-runner)"
                echo "  --nfs-only              Only setup NFS, skip runner installation"
                echo "  -h, --help              Show this help message"
                exit 0
                ;;
            *)
                print_error "Unknown option: $1"
                exit 1
                ;;
        esac
    done

    # Run setup steps
    check_microk8s
    check_helm
    enable_nfs
    create_namespace "$NAMESPACE"
    deploy_pvc "$NAMESPACE"

    if [ "$SKIP_INSTALL" = false ]; then
        verify_values
        add_helm_repo

        echo ""
        print_warning "About to install GitLab Runner with the following configuration:"
        echo "  Namespace: $NAMESPACE"
        echo "  Release Name: $RELEASE_NAME"
        echo ""
        read -p "Continue with installation? (y/N) " -n 1 -r
        echo

        if [[ $REPLY =~ ^[Yy]$ ]]; then
            install_runner "$NAMESPACE" "$RELEASE_NAME"
            show_status "$NAMESPACE"
        else
            print_info "Installation skipped. You can install manually later with:"
            echo "  helm install $RELEASE_NAME gitlab/gitlab-runner --version 0.82.0 -f values.yaml"
        fi
    else
        print_info "NFS setup completed. Skipping runner installation."
        echo ""
        print_info "To install runner later, run:"
        echo "  helm install $RELEASE_NAME gitlab/gitlab-runner --version 0.82.0 -f values.yaml"
    fi

    echo ""
    print_info "Setup completed successfully!"
}

# Run main
main "$@"
