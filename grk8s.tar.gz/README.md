# GitLab Runner on MicroK8s with Shared PVC Cache

This configuration deploys GitLab Runner on a MicroK8s multi-node cluster with shared cache using Persistent Volume Claims (PVC).

## Prerequisites

1. **MicroK8s cluster** (multi-node setup)
2. **MicroK8s NFS addon** enabled (for ReadWriteMany storage)
3. **Helm 3** installed
4. **kubectl** configured for your cluster
5. **GitLab instance** with runner registration token

## Architecture

- **GitLab Runner**: Deployed via Helm chart v0.82.0
- **Cache Storage**: MicroK8s NFS CSI (ReadWriteMany)
- **Executor**: Kubernetes
- **Cache Type**: Local filesystem backed by NFS PVC
- **Multi-Node**: Full shared cache across all cluster nodes

## Setup MicroK8s NFS Storage

This configuration uses the MicroK8s NFS addon which provides `ReadWriteMany` (RWX) storage, allowing multiple pods across different nodes to access the cache simultaneously.

### Enable NFS Addon

```bash
# 1. Enable community repository (if not already enabled)
microk8s enable community

# 2. Enable NFS CSI driver
microk8s enable nfs

# 3. Verify NFS storage class is available
microk8s kubectl get storageclass nfs-csi
```

Expected output:
```
NAME      PROVISIONER       RECLAIMPOLICY   VOLUMEBINDINGMODE   ALLOWVOLUMEEXPANSION   AGE
nfs-csi   nfs.csi.k8s.io    Delete          Immediate           false                  30s
```

### NFS Server Configuration

The MicroK8s NFS addon automatically sets up an NFS server on one of your cluster nodes. By default:

- **NFS Server**: Runs on the node where it's first enabled
- **Storage Path**: `/srv/nfs` on the NFS server node
- **Access Mode**: ReadWriteMany (multiple pods, multiple nodes)
- **Network**: Uses cluster internal networking

### Verify NFS Server

```bash
# Check NFS server pod
microk8s kubectl get pods -n nfs-server-provisioner

# Check NFS server service
microk8s kubectl get svc -n nfs-server-provisioner
```

## Quick Start (Automated Setup)

Use the provided setup script for automated deployment:

```bash
# Setup NFS and deploy everything (will prompt for confirmation)
./setup-nfs-cache.sh

# Setup in custom namespace
./setup-nfs-cache.sh --namespace gitlab-runner

# Only setup NFS storage, skip runner installation
./setup-nfs-cache.sh --nfs-only

# Show help
./setup-nfs-cache.sh --help
```

The script will:
1. ✅ Verify MicroK8s and Helm are installed
2. ✅ Enable NFS addon with community repository
3. ✅ Create namespace (if needed)
4. ✅ Deploy the cache PVC
5. ✅ Add GitLab Helm repository
6. ✅ Install GitLab Runner
7. ✅ Show deployment status

## Manual Deployment Steps

If you prefer manual deployment, follow these steps:

### 1. Add GitLab Helm Repository

```bash
helm repo add gitlab https://charts.gitlab.io
helm repo update
```

### 2. Update Configuration

Edit [`values.yaml`](values.yaml) and update:

```yaml
# Your GitLab instance URL
gitlabUrl: https://gitlab.example.com/

# Get this from: GitLab > Settings > CI/CD > Runners
runnerRegistrationToken: "YOUR_REGISTRATION_TOKEN_HERE"

# Optional: Add runner tags
runnerTags: "k8s,microk8s,shared-cache"
```

### 3. Create Namespace (Optional)

```bash
kubectl create namespace gitlab-runner
```

### 4. Deploy the Cache PVC

**Important**: Deploy this BEFORE installing the runner!

```bash
# If using custom namespace, edit the namespace in gitlab-runner-cache-pvc.yaml first
kubectl apply -f gitlab-runner-cache-pvc.yaml

# Verify PVC is created and bound
kubectl get pvc gitlab-runner-cache
```

Expected output:
```
NAME                   STATUS   VOLUME                                     CAPACITY   ACCESS MODES   STORAGECLASS   AGE
gitlab-runner-cache    Bound    pvc-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx   10Gi       RWX            nfs-csi        10s
```

**Note**: The `ACCESS MODES` should show `RWX` (ReadWriteMany), enabling multi-node shared access.

### 5. Install GitLab Runner

```bash
# Install in default namespace
helm install gitlab-runner gitlab/gitlab-runner \
  --version 0.82.0 \
  -f values.yaml

# OR install in custom namespace
helm install gitlab-runner gitlab/gitlab-runner \
  --version 0.82.0 \
  --namespace gitlab-runner \
  -f values.yaml
```

### 6. Verify Installation

```bash
# Check runner pod
kubectl get pods -l app=gitlab-runner

# Check runner logs
kubectl logs -l app=gitlab-runner

# Verify runner registered in GitLab
# Go to: GitLab > Settings > CI/CD > Runners
```

## Testing the Cache

### 1. Add Pipeline to Repository

Copy [`.gitlab-ci.yml`](.gitlab-ci.yml) to the root of your GitLab repository:

```bash
cp .gitlab-ci.yml /path/to/your/gitlab/repo/
cd /path/to/your/gitlab/repo/
git add .gitlab-ci.yml
git commit -m "Add pipeline with shared cache"
git push
```

### 2. Run Pipeline

The example pipeline demonstrates:

1. **Initialize Cache**: Creates/updates a build counter file
2. **Build Job**: Reads counter and writes build metadata
3. **Test Jobs**: Verify cache access and show parallel access
4. **Cleanup**: Manual job to clean cache (optional)

### 3. Verify Installation

Use the verification script to check everything is working:

```bash
# Run verification in default namespace
./verify-cache.sh

# Or specify namespace
./verify-cache.sh gitlab-runner
```

The script will test:
- ✅ NFS addon is enabled
- ✅ NFS storage class exists
- ✅ NFS server pod is running
- ✅ PVC is bound with ReadWriteMany
- ✅ GitLab Runner is registered
- ✅ Cache is accessible from pods
- ✅ Cache read/write operations work

### 4. Monitor Cache

```bash
# Check PVC usage
kubectl get pvc gitlab-runner-cache

# Exec into a runner pod to inspect cache
kubectl exec -it <runner-pod-name> -- sh
ls -lh /cache/
cat /cache/build-counter.txt
```

## Cache Behavior

### What Gets Cached

The pipeline writes to `/cache` which is backed by the PVC:

- `build-counter.txt`: Incremental build counter
- `build-history.log`: Build execution history
- `test-results.log`: Test execution logs
- Any other files your jobs write to `/cache`

### Cache Persistence

- **Persistent**: Data survives pod restarts and job completions
- **Shared**: Multiple jobs can access the same cache (with RWX)
- **Manual Cleanup**: Use the `cleanup_cache` job or manually delete files

### Cache Capabilities

With `ReadWriteMany` (NFS CSI):
- ✅ Multiple pods across nodes can access simultaneously
- ✅ True shared cache across the entire cluster
- ✅ Parallel jobs on different nodes share the same cache
- ✅ Cache persists across pod restarts and node failures
- ✅ No serialization - all jobs access cache concurrently

## Troubleshooting

### NFS Addon Not Enabled

```bash
# Verify NFS addon is enabled
microk8s status

# If not enabled, enable it
microk8s enable community
microk8s enable nfs

# Verify storage class exists
kubectl get storageclass nfs-csi
```

### PVC Not Mounting

```bash
# Check PVC status
kubectl get pvc gitlab-runner-cache
kubectl describe pvc gitlab-runner-cache

# Check NFS server is running
kubectl get pods -n nfs-server-provisioner

# Check persistent volume
kubectl get pv
kubectl describe pv <pv-name>
```

### Runner Not Starting

```bash
# Check runner pod
kubectl get pods -l app=gitlab-runner
kubectl describe pod <runner-pod-name>
kubectl logs <runner-pod-name>
```

### Cache Not Working

```bash
# Verify PVC is mounted in job pods
kubectl get pods  # Find a job pod
kubectl describe pod <job-pod-name>
kubectl exec -it <job-pod-name> -- ls -lh /cache/
```

### Permission Issues

```bash
# The cache directory should be writable
# Check PVC permissions
kubectl exec -it <job-pod-name> -- sh -c "touch /cache/test.txt && rm /cache/test.txt"
```

## Upgrading

```bash
# Update values.yaml with new configuration
# Then upgrade the release
helm upgrade gitlab-runner gitlab/gitlab-runner \
  --version 0.82.0 \
  -f values.yaml
```

## Cleanup

```bash
# Uninstall runner
helm uninstall gitlab-runner

# Delete PVC (WARNING: This deletes all cached data!)
kubectl delete -f gitlab-runner-cache-pvc.yaml

# Delete namespace (if created)
kubectl delete namespace gitlab-runner
```

## Configuration Reference

### Key Configuration Options

#### values.yaml

- `concurrent`: Max number of concurrent jobs (default: 10)
- `checkInterval`: How often to check for new jobs in seconds (default: 30)
- `runners.config`: TOML configuration for runner behavior
- `resources`: CPU/memory limits for runner manager pod

#### Cache Configuration

```toml
[runners.cache]
  Type = "local"           # Use local filesystem
  Path = "/cache"          # Cache mount path
  Shared = true            # Share cache between jobs

[runners.kubernetes.volumes.pvc]
  name = "gitlab-runner-cache"  # PVC name
  mount_path = "/cache"         # Where to mount in job pods
  read_only = false             # Allow write access
```

## Advanced Configuration

### Automated Setup Script

The [`setup-nfs-cache.sh`](setup-nfs-cache.sh) script provides automated deployment with options:

```bash
# Basic usage
./setup-nfs-cache.sh

# With options
./setup-nfs-cache.sh --namespace gitlab-runner --release my-runner

# Only setup NFS, no runner installation
./setup-nfs-cache.sh --nfs-only
```

**Script Options:**
- `-n, --namespace NAME`: Kubernetes namespace (default: default)
- `-r, --release NAME`: Helm release name (default: gitlab-runner)
- `--nfs-only`: Only setup NFS storage, skip runner installation
- `-h, --help`: Show help message

The script includes:
- Pre-flight checks for MicroK8s and Helm
- Automatic NFS addon enablement
- PVC deployment and verification
- Optional interactive runner installation
- Post-deployment status report

### Multiple Runners

Deploy multiple runners with different configurations:

```bash
helm install gitlab-runner-1 gitlab/gitlab-runner -f values-runner-1.yaml
helm install gitlab-runner-2 gitlab/gitlab-runner -f values-runner-2.yaml
```

### Node Affinity

Pin runners to specific nodes:

```yaml
# In values.yaml
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
      - matchExpressions:
        - key: node-role.kubernetes.io/worker
          operator: In
          values:
          - "true"
```

### Resource Limits

Adjust job pod resources:

```yaml
# In values.yaml runners.config section
[runners.kubernetes]
  cpu_limit = "4"
  cpu_request = "1"
  memory_limit = "4Gi"
  memory_request = "1Gi"
```

## Included Scripts

This repository includes three helper scripts:

1. **[setup-nfs-cache.sh](setup-nfs-cache.sh)** - Automated setup and deployment
   - Enables NFS addon
   - Creates PVC
   - Installs GitLab Runner
   - Interactive with confirmation prompts

2. **[verify-cache.sh](verify-cache.sh)** - Verification and testing
   - Tests all components
   - Verifies cache access
   - Creates test pods to validate functionality
   - Provides detailed status report

3. **[.gitlab-ci.yml](.gitlab-ci.yml)** - Example pipeline
   - Demonstrates cache usage
   - Shows read/write operations
   - Tests parallel job access
   - Includes cleanup jobs

## Resources

- [GitLab Runner Helm Chart Documentation](https://docs.gitlab.com/runner/install/kubernetes/)
- [GitLab Runner Configuration](https://docs.gitlab.com/runner/configuration/)
- [Kubernetes Executor](https://docs.gitlab.com/runner/executors/kubernetes/)
- [MicroK8s NFS Addon](https://microk8s.io/docs/addon-nfs)
- [MicroK8s Storage Documentation](https://microk8s.io/docs/addon-hostpath-storage)

## License

This configuration is provided as-is for use with GitLab Runner and MicroK8s.
