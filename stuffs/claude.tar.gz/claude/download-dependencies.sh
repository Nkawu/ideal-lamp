#!/bin/bash
# Script to download all dependencies for isolated OpenTelemetry C++ RPM build
# Run this script on a machine with internet access before transferring to isolated environment

set -e

echo "======================================"
echo "OpenTelemetry C++ Dependency Downloader"
echo "======================================"

# Create directory structure
mkdir -p local-repo
cd local-repo

echo ""
echo "[1/3] Downloading OpenTelemetry C++ source..."
if [ ! -f v1.10.0.tar.gz ]; then
    wget https://github.com/open-telemetry/opentelemetry-cpp/archive/v1.10.0.tar.gz
    mv v1.10.0.tar.gz ../
    echo "✓ Source tarball downloaded"
else
    echo "✓ Source tarball already exists"
fi

cd ..

echo ""
echo "[2/3] Downloading UBI8 base image..."
echo "Note: You must have Docker/Podman installed to save the base image"
if command -v docker &> /dev/null; then
    docker pull registry.access.redhat.com/ubi8/ubi:latest
    docker save registry.access.redhat.com/ubi8/ubi:latest -o ubi8-base.tar
    echo "✓ Base image saved to ubi8-base.tar"
    echo "  Load with: docker load -i ubi8-base.tar"
elif command -v podman &> /dev/null; then
    podman pull registry.access.redhat.com/ubi8/ubi:latest
    podman save registry.access.redhat.com/ubi8/ubi:latest -o ubi8-base.tar
    echo "✓ Base image saved to ubi8-base.tar"
    echo "  Load with: podman load -i ubi8-base.tar"
else
    echo "⚠ Docker/Podman not found. You'll need to download the base image manually."
fi

echo ""
echo "[3/3] Downloading RPM dependencies..."
echo "This will create a temporary UBI8 container to download all RPMs with dependencies"

# Create a temporary Dockerfile to download dependencies
cat > Dockerfile.download <<'EOF'
FROM registry.access.redhat.com/ubi8/ubi:latest

# Enable EPEL and PowerTools
RUN dnf install -y \
    https://dl.fedoraproject.org/pub/epel/epel-release-latest-8.noarch.rpm && \
    (dnf config-manager --set-enabled powertools || \
     dnf config-manager --set-enabled codeready-builder-for-rhel-8-rhui-rpms || true)

# Download all required packages and their dependencies
RUN mkdir -p /downloaded-rpms && \
    cd /downloaded-rpms && \
    dnf install -y --downloadonly --downloaddir=/downloaded-rpms \
        rpm-build \
        rpmdevtools \
        gcc-c++ \
        cmake \
        make \
        curl-devel \
        openssl-devel \
        zlib-devel \
        protobuf-devel \
        protobuf-compiler \
        grpc-devel \
        grpc-plugins \
        createrepo \
    && dnf install -y --downloadonly --downloaddir=/downloaded-rpms \
        nlohmann-json-devel || true

# Create repository metadata
RUN createrepo /downloaded-rpms

CMD ["/bin/bash"]
EOF

echo "Building temporary container to download packages..."
if command -v docker &> /dev/null; then
    RUNTIME="docker"
elif command -v podman &> /dev/null; then
    RUNTIME="podman"
else
    echo "ERROR: Neither docker nor podman found. Cannot download dependencies."
    exit 1
fi

$RUNTIME build -f Dockerfile.download -t otel-rpm-downloader .

echo "Extracting downloaded RPMs..."
CONTAINER_ID=$($RUNTIME create otel-rpm-downloader)
$RUNTIME cp $CONTAINER_ID:/downloaded-rpms ./local-repo/
$RUNTIME rm $CONTAINER_ID
$RUNTIME rmi otel-rpm-downloader

# Cleanup
rm Dockerfile.download

# If nlohmann-json-devel is not available as RPM, download the header
if ! ls local-repo/downloaded-rpms/nlohmann-json-devel*.rpm 1> /dev/null 2>&1; then
    echo ""
    echo "⚠ nlohmann-json-devel RPM not found in repositories"
    echo "  Downloading header file as fallback..."
    mkdir -p nlohmann-json-headers
    wget -O nlohmann-json-headers/json.hpp \
        https://github.com/nlohmann/json/releases/download/v3.11.2/json.hpp
    echo "✓ nlohmann-json header downloaded to nlohmann-json-headers/"
fi

# Move RPMs to correct location
if [ -d local-repo/downloaded-rpms ]; then
    mv local-repo/downloaded-rpms/*.rpm local-repo/ 2>/dev/null || true
    rm -rf local-repo/downloaded-rpms
fi

echo ""
echo "======================================"
echo "Download Complete!"
echo "======================================"
echo ""
echo "Files created:"
echo "  - v1.10.0.tar.gz (OpenTelemetry C++ source)"
echo "  - ubi8-base.tar (UBI8 base image)"
echo "  - local-repo/*.rpm (all dependency RPMs)"
echo "  - nlohmann-json-headers/ (optional, if RPM not available)"
echo ""
echo "Transfer these files to your isolated environment and run:"
echo "  1. Load base image: docker load -i ubi8-base.tar"
echo "  2. Build container: docker build -t opentelemetry-cpp-builder ."
echo ""
echo "Note: Ensure Dockerfile and opentelemetry-cpp.spec are also transferred."
