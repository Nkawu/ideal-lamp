# OpenTelemetry C++ RPM Build Instructions

This repository contains the necessary files to build OpenTelemetry C++ v1.10.0 RPM packages in an isolated UBI8 container environment **without internet access**.

## Files

- **Dockerfile** - UBI8-based container definition for building RPMs in isolated environment
- **opentelemetry-cpp.spec** - RPM spec file for OpenTelemetry C++
- **download-dependencies.sh** - Helper script to download all dependencies before transferring to isolated environment

## Prerequisites

- Docker or Podman installed on your system
- For isolated/air-gapped environments: Run [download-dependencies.sh](download-dependencies.sh) on a machine with internet access first

## Building in Isolated Environment (No Internet Access)

The Dockerfile is designed to work in completely isolated environments without any internet connectivity. Follow these steps:

### Step 1: Download Dependencies (on internet-connected machine)

On a machine with internet access, run the dependency download script:

```bash
# Make the script executable
chmod +x download-dependencies.sh

# Run the script to download all dependencies
./download-dependencies.sh
```

This will create:
- `v1.10.0.tar.gz` - OpenTelemetry C++ source code
- `ubi8-base.tar` - UBI8 base Docker image
- `local-repo/*.rpm` - All required dependency RPMs with metadata
- `nlohmann-json-headers/` - Optional fallback headers (if RPM not available)

### Step 2: Transfer to Isolated Environment

Transfer the following files to your isolated environment:
```
├── Dockerfile
├── opentelemetry-cpp.spec
├── v1.10.0.tar.gz
├── ubi8-base.tar
└── local-repo/
    ├── *.rpm (all dependency RPMs)
    └── repodata/ (repository metadata)
```

### Step 3: Load Base Image (on isolated machine)

```bash
# Load the UBI8 base image
docker load -i ubi8-base.tar

# Or with Podman
podman load -i ubi8-base.tar
```

### Step 4: Build the RPMs (on isolated machine)

```bash
# Build the Docker image (no internet required)
docker build -t opentelemetry-cpp-builder .

# Create a container from the image
docker create --name otel-build opentelemetry-cpp-builder

# Extract the built RPMs to your host
docker cp otel-build:/root/rpmbuild/RPMS ./rpms
docker cp otel-build:/root/rpmbuild/SRPMS ./srpms

# Cleanup the container
docker rm otel-build
```

## Building with Internet Access (Alternative)

If you have internet access, you can use a simpler build process. See the original online Dockerfile in git history or use the download script's temporary Dockerfile.

## Additional Build Methods

### Interactive Build

For debugging or customization in the isolated environment:

```bash
# Build the image without running the final rpmbuild
docker build --target <intermediate-stage> -t opentelemetry-cpp-builder .

# Run the container interactively
docker run -it opentelemetry-cpp-builder /bin/bash

# Inside the container, manually build the RPMs
cd /root/rpmbuild/SPECS
rpmbuild -ba opentelemetry-cpp.spec

# The RPMs will be in:
# - /root/rpmbuild/RPMS/x86_64/ (binary RPMs)
# - /root/rpmbuild/SRPMS/ (source RPM)
```

### Using Podman

All Docker commands can be replaced with Podman:

```bash
# Load base image
podman load -i ubi8-base.tar

# Build with Podman
podman build -t opentelemetry-cpp-builder .

# Create and extract
podman create --name otel-build opentelemetry-cpp-builder
podman cp otel-build:/root/rpmbuild/RPMS ./rpms
podman cp otel-build:/root/rpmbuild/SRPMS ./srpms
podman rm otel-build
```

## Generated Packages

After a successful build, you will have the following RPM packages:

1. **opentelemetry-cpp-1.10.0-1.el8.x86_64.rpm**
   - Runtime libraries
   - Required for applications using OpenTelemetry C++

2. **opentelemetry-cpp-devel-1.10.0-1.el8.x86_64.rpm**
   - Development headers and files
   - CMake configuration files
   - pkg-config files
   - Required for building applications with OpenTelemetry C++

3. **opentelemetry-cpp-1.10.0-1.el8.src.rpm**
   - Source RPM containing the spec file and source tarball
   - Can be used to rebuild the package

## Installing the RPMs

On a RHEL 8 / UBI8 / Rocky Linux 8 / AlmaLinux 8 system:

```bash
# Install runtime package
sudo dnf install ./rpms/x86_64/opentelemetry-cpp-1.10.0-1.el8.x86_64.rpm

# Install development package (includes runtime as dependency)
sudo dnf install ./rpms/x86_64/opentelemetry-cpp-devel-1.10.0-1.el8.x86_64.rpm
```

## Features Included

The OpenTelemetry C++ build includes:

- ✅ OTLP Exporter (gRPC)
- ✅ OTLP Exporter (HTTP)
- ✅ Zipkin Exporter
- ✅ Prometheus Exporter
- ✅ Shared libraries
- ✅ Full API and SDK

## Customization

### Modifying the Build

To customize the build, edit [opentelemetry-cpp.spec](opentelemetry-cpp.spec):

```spec
# Enable/disable features in the %build section
-DWITH_OTLP=ON \
-DWITH_OTLP_GRPC=ON \
-DWITH_OTLP_HTTP=ON \
-DWITH_ZIPKIN=ON \
-DWITH_PROMETHEUS=ON \
```

### Adding Dependencies

To add build dependencies, edit [Dockerfile](Dockerfile):

```dockerfile
RUN dnf install -y \
    your-additional-package \
    another-dependency
```

Or add to the `BuildRequires:` section in [opentelemetry-cpp.spec](opentelemetry-cpp.spec).

## Troubleshooting

### Build Fails with Missing Dependencies in Isolated Environment

If the build fails due to missing dependencies:

1. **Check the local repository:**
   ```bash
   # Run container interactively
   docker run -it opentelemetry-cpp-builder /bin/bash

   # Inside container, check what's available
   ls -la /tmp/local-repo/
   dnf repolist
   ```

2. **Re-download dependencies on internet-connected machine:**
   ```bash
   # Delete old dependencies
   rm -rf local-repo/*

   # Re-run download script
   ./download-dependencies.sh
   ```

3. **Manually add missing RPMs:**
   ```bash
   # On internet-connected machine, download specific package
   dnf download --resolve --destdir=local-repo <package-name>

   # Rebuild repository metadata
   createrepo local-repo/

   # Transfer to isolated environment
   ```

### Protobuf/gRPC Version Issues

OpenTelemetry C++ v1.10.0 requires specific versions of protobuf and gRPC. If you encounter version conflicts, you may need to:

1. Build protobuf and gRPC from source
2. Use a different base image with newer packages
3. Use a different version of OpenTelemetry C++

### Extracting RPMs Without Docker CP

Alternative method to extract RPMs:

```bash
# Mount a volume during build
docker run -v $(pwd)/output:/output opentelemetry-cpp-builder \
    cp -r /root/rpmbuild/RPMS /output/
```

### Base Image Not Loading in Isolated Environment

If you cannot load the base image:

```bash
# Verify the tar file is not corrupted
tar -tzf ubi8-base.tar | head

# Try alternative load methods
docker load < ubi8-base.tar

# Check loaded images
docker images | grep ubi8
```

### nlohmann-json Not Available

If nlohmann-json-devel RPM is not available in your repositories:

1. The [download-dependencies.sh](download-dependencies.sh) script downloads the header file as fallback
2. Manually install it in the Dockerfile:
   ```dockerfile
   COPY nlohmann-json-headers/json.hpp /usr/include/nlohmann/json.hpp
   ```

## Testing the Installation

After installing the RPMs, verify the installation:

```bash
# Check installed files
rpm -ql opentelemetry-cpp
rpm -ql opentelemetry-cpp-devel

# Verify libraries
ldconfig -p | grep opentelemetry

# Check headers
ls /usr/include/opentelemetry/

# Verify pkg-config
pkg-config --modversion opentelemetry-cpp
```

## Building on Different Architectures

To build for different architectures (e.g., ARM64):

```bash
# Using Docker buildx
docker buildx build --platform linux/arm64 -t opentelemetry-cpp-builder .

# Using Podman
podman build --arch arm64 -t opentelemetry-cpp-builder .
```

## License

OpenTelemetry C++ is licensed under the Apache License 2.0. See the LICENSE file in the OpenTelemetry C++ repository for details.

## Additional Resources

- [OpenTelemetry C++ GitHub](https://github.com/open-telemetry/opentelemetry-cpp)
- [OpenTelemetry Documentation](https://opentelemetry.io/docs/)
- [RPM Packaging Guide](https://rpm-packaging-guide.github.io/)
