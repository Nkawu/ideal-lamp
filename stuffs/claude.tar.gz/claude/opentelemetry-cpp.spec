Name:           opentelemetry-cpp
Version:        1.10.0
Release:        1%{?dist}
Summary:        OpenTelemetry C++ Client

License:        Apache-2.0
URL:            https://github.com/open-telemetry/opentelemetry-cpp
Source0:        https://github.com/open-telemetry/opentelemetry-cpp/archive/v%{version}.tar.gz

BuildRequires:  gcc-c++
BuildRequires:  cmake >= 3.15
BuildRequires:  make
BuildRequires:  curl-devel
BuildRequires:  protobuf-devel >= 3.0
BuildRequires:  grpc-devel
BuildRequires:  grpc-plugins
BuildRequires:  openssl-devel
BuildRequires:  zlib-devel
BuildRequires:  nlohmann-json-devel

%description
OpenTelemetry C++ is the C++ implementation of the OpenTelemetry API and SDK.
It provides a vendor-agnostic implementation for distributed tracing, metrics,
and logging.

%package devel
Summary:        Development files for OpenTelemetry C++
Requires:       %{name}%{?_isa} = %{version}-%{release}
Requires:       curl-devel
Requires:       protobuf-devel
Requires:       grpc-devel

%description devel
Development files and headers for OpenTelemetry C++. This package contains
the libraries and header files needed to develop applications using
OpenTelemetry C++.

%prep
%setup -q -n %{name}-%{version}

%build
mkdir -p build
cd build
%cmake3 \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_INSTALL_PREFIX=%{_prefix} \
    -DBUILD_SHARED_LIBS=ON \
    -DWITH_OTLP=ON \
    -DWITH_OTLP_GRPC=ON \
    -DWITH_OTLP_HTTP=ON \
    -DWITH_ZIPKIN=ON \
    -DWITH_PROMETHEUS=ON \
    -DWITH_EXAMPLES=OFF \
    -DWITH_TESTS=OFF \
    -DBUILD_TESTING=OFF \
    -DWITH_BENCHMARK=OFF \
    ..

%make_build

%install
cd build
%make_install

# Remove static libraries if any
find %{buildroot} -name '*.a' -delete

# Remove la files
find %{buildroot} -name '*.la' -delete

%files
%license LICENSE
%doc README.md
%{_libdir}/libopentelemetry_*.so.*

%files devel
%{_includedir}/opentelemetry/
%{_libdir}/libopentelemetry_*.so
%{_libdir}/pkgconfig/opentelemetry-*.pc
%{_libdir}/cmake/opentelemetry-cpp/

%changelog
* %(date "+%a %b %d %Y") Builder <builder@example.com> - 1.10.0-1
- Initial RPM build of OpenTelemetry C++ v1.10.0
