import os
import xml.etree.ElementTree as ET
import glob

# Paths
base_folder = "/workspaces/models"
xml_folder = f"{base_folder}/work/Annotation"  # Folder containing XML files
txt_folder = f"{base_folder}/work/yolo_labels"  # Folder to save YOLO labels
classes_file = f"{base_folder}/scripts/classes.txt"  # File containing class names

# Ensure the output directory exists
os.makedirs(txt_folder, exist_ok=True)

# Load class names
classes = []
if os.path.exists(classes_file):
    with open(classes_file, "r") as f:
        classes = [line.strip() for line in f.readlines()]

# Convert XML to YOLO format
def convert_xml_to_yolo(xml_file):
    tree = ET.parse(xml_file)
    root = tree.getroot()

    # Get image size
    size = root.find("size")
    img_w = int(size.find("width").text)
    img_h = int(size.find("height").text)

    # Get object annotations
    yolo_data = []
    for obj in root.findall("object"):
        class_name = obj.find("name").text

        # Ensure class is in the list
        if class_name not in classes:
            classes.append(class_name)

        class_id = classes.index(class_name)
        bbox = obj.find("bndbox")
        xmin = int(bbox.find("xmin").text)
        ymin = int(bbox.find("ymin").text)
        xmax = int(bbox.find("xmax").text)
        ymax = int(bbox.find("ymax").text)

        # Convert to YOLO format
        x_center = (xmin + xmax) / 2 / img_w
        y_center = (ymin + ymax) / 2 / img_h
        width = (xmax - xmin) / img_w
        height = (ymax - ymin) / img_h

        yolo_data.append(f"{class_id} {x_center:.6f} {y_center:.6f} {width:.6f} {height:.6f}")

    return yolo_data

# Process all XML files
for xml_file in glob.glob(f"{xml_folder}/**/*.xml"):
    yolo_annotations = convert_xml_to_yolo(xml_file)

    # Save to corresponding .txt file
    # txt_file = os.path.join(txt_folder, xml_file.replace(".xml", ".txt"))
    txt_file = xml_file.replace(".xml", ".txt")
    with open(txt_file, "w") as f:
        f.write("\n".join(yolo_annotations))

# Save class names
with open(classes_file, "w") as f:
    f.write("\n".join(classes))

print("Conversion complete!")
