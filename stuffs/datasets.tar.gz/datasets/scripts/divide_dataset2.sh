#!/usr/bin/env bash

# Set the paths for the train folder, label folder, and target folder
base_folder="/workspaces/models"
image_folder_path="${base_folder}/work/Images"
label_folder_path="${base_folder}/work/Annotation"
target_train_folder="${base_folder}/target/train"
target_val_folder="${base_folder}/target/val"
target_test_folder="${base_folder}/target/test"

# Create the target folders if they don't exist
mkdir -p "${target_train_folder}"
mkdir -p "${target_val_folder}"
mkdir -p "${target_test_folder}"

# Clear the target folders if they are not empty
rm -rf "${target_train_folder}"/*
rm -rf "${target_val_folder}"/*
rm -rf "${target_test_folder}"/*

# Loop through the class folders in the train folder
for class_folder in "${image_folder_path}"/*; do
    
    # Extract the class name from the class folder path
    class_name=$(basename "${class_folder}")
    
    # Create the corresponding class folders in the target folders
    for d in images labels; do
        mkdir -p "${target_train_folder}/${d}"
        mkdir -p "${target_val_folder}/${d}"
        mkdir -p "${target_test_folder}/${d}"
    done
    
    # Move the image files to the respective target folders
    for jpg_file in $class_folder/*.jpg; do
        # Get the base filename without the extension
        filename=$(basename "${jpg_file}" .jpg)
        txt_file="${label_folder_path}/${class_name}/${filename}.txt"

        # Generate a random number between 0 and 1
        rand=$(shuf -i 0-1000 -n 1)

        # Decide the split based on the random number
        if [ ${rand} -le 700 ]; then
            mv "${jpg_file}" "${target_train_folder}/images/"
            mv "${txt_file}" "${target_train_folder}/labels/"
        elif [ ${rand} -le 900 ]; then
            mv "${jpg_file}" "${target_val_folder}/images/"
            mv "${txt_file}" "${target_val_folder}/labels/"
        else
            mv "${jpg_file}" "${target_test_folder}/images/"
            mv "${txt_file}" "${target_test_folder}/labels/"
        fi
    done;
done

echo "Images divided into train, validation, and test splits successfully!"