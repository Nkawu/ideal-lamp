# Datasets

```bash
cd /workspaces/models

# download dataset
mkdir -p stanford_dogs && cd $_
curl -O http://vision.stanford.edu/aditya86/ImageNetDogs/images.tar
curl -O http://vision.stanford.edu/aditya86/ImageNetDogs/annotation.tar
cd ..

# untar dataset
mkdir -p work
tar -xf stanford_dogs/images.tar -C work/; tar -xf stanford_dogs/annotation.tar -C work/

# rename annotation XML files
cd /workspaces/models/work/Annotation/
find . -type f ! -name "*.*" -exec sh -c 'f="{}"; mv -v "$f" "$f.xml"' \;

# convert PASCAL VOC annotation XML files to YOLO label TXT files
/usr/local/bin/python /workspaces/models/scripts/convert_xml_txt.py

# split dataset
cd /workspaces/models
/workspaces/models/scripts/divide_dataset2.sh

target
  +- test/train/val
     +- class
        +- images
        +- labels

```