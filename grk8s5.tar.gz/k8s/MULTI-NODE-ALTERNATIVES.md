# Multi-Node Cache Sharing Alternatives

Since `nfs-csi` storage class is not available, here are alternative approaches for sharing cache across 3 nodes.

## Current Limitation

The default MicroK8s `hostpath` storage uses **ReadWriteOnce (RWO)** which means:
- ❌ Only one node can mount the volume at a time
- ❌ Jobs must run on the same node to share cache
- ✅ Fast local disk performance
- ✅ Simple setup

## Option 1: External NFS Server (Recommended)

**Use this if you have an existing NFS server in your network.**

### Prerequisites
- NFS server accessible from all cluster nodes
- NFS share exported and accessible

### Setup Steps

1. **Configure the NFS server** (on your NFS server machine):
```bash
# Example: Export /data/gitlab-cache
# Add to /etc/exports:
/data/gitlab-cache *(rw,sync,no_subtree_check,no_root_squash)

# Restart NFS
sudo exportfs -ra
sudo systemctl restart nfs-kernel-server
```

2. **Update the PV/PVC file** [`gitlab-runner-cache-pv-external-nfs.yaml`](gitlab-runner-cache-pv-external-nfs.yaml):
```bash
# Edit the file and replace:
# - NFS_SERVER_IP with your NFS server IP (e.g., 192.168.1.100)
# - /path/to/export with your NFS export path (e.g., /data/gitlab-cache)

nano gitlab-runner-cache-pv-external-nfs.yaml
```

3. **Deploy the PV and PVC**:
```bash
kubectl apply -f gitlab-runner-cache-pv-external-nfs.yaml
kubectl get pvc gitlab-runner-cache
```

4. **Verify**:
```bash
kubectl get pvc gitlab-runner-cache
# Should show: STATUS=Bound, ACCESS MODES=RWX
```

### Pros & Cons
- ✅ True multi-node shared access
- ✅ Centralized cache management
- ✅ Can use existing infrastructure
- ❌ Requires external NFS server
- ⚠️ Network dependency

---

## Option 2: Deploy NFS Server in Kubernetes

**Use this if you don't have an external NFS server.**

This deploys an NFS server as a pod in your cluster.

### Setup Steps

1. **Deploy the NFS server**:
```bash
kubectl apply -f nfs-server-deployment.yaml

# Wait for NFS server to be ready
kubectl wait --for=condition=ready pod -l app=nfs-server -n nfs-server --timeout=120s
```

2. **Get the NFS service IP**:
```bash
NFS_IP=$(kubectl get svc -n nfs-server nfs-server -o jsonpath='{.spec.clusterIP}')
echo "NFS Server IP: $NFS_IP"
```

3. **Update the PV in the deployment file**:
```bash
# Edit nfs-server-deployment.yaml
# Replace NFS_SERVER_SERVICE_IP with the IP from step 2
nano nfs-server-deployment.yaml

# Apply just the PV and PVC parts
kubectl apply -f nfs-server-deployment.yaml
```

4. **Verify**:
```bash
kubectl get pvc gitlab-runner-cache
# Should show: STATUS=Bound, ACCESS MODES=RWX
```

### Pros & Cons
- ✅ No external dependencies
- ✅ True multi-node shared access
- ✅ All-in-Kubernetes solution
- ⚠️ Single point of failure (1 NFS pod)
- ⚠️ NFS pod must run on one node with RWO storage

---

## Option 3: Use Longhorn (Distributed Storage)

**Use this for production-grade distributed storage.**

### Setup Steps

1. **Install Longhorn**:
```bash
kubectl apply -f https://raw.githubusercontent.com/longhorn/longhorn/v1.5.3/deploy/longhorn.yaml

# Wait for Longhorn to be ready (may take 5-10 minutes)
kubectl get pods -n longhorn-system --watch
```

2. **Update PVC to use Longhorn**:
```yaml
# Edit gitlab-runner-cache-pvc.yaml
spec:
  accessModes:
    - ReadWriteMany
  storageClassName: "longhorn"
  resources:
    requests:
      storage: 10Gi
```

3. **Deploy PVC**:
```bash
kubectl apply -f gitlab-runner-cache-pvc.yaml
```

### Pros & Cons
- ✅ Distributed, replicated storage
- ✅ Web UI for management
- ✅ Snapshots and backups
- ✅ High availability
- ❌ Resource intensive (requires more CPU/RAM)
- ❌ More complex setup

---

## Option 4: Single Node with Job Affinity (Simplest)

**Use this if multi-node sharing isn't critical.**

Keep jobs on the same node using node affinity.

### Setup Steps

1. **Use default hostpath PVC**:
```bash
# Current gitlab-runner-cache-pvc.yaml already configured for this
kubectl apply -f gitlab-runner-cache-pvc.yaml
```

2. **Add node affinity to values.yaml**:
```yaml
# Add to values.yaml under runners.config
runners:
  config: |
    [[runners]]
      [runners.kubernetes]
        # ... existing config ...

        # Pin all jobs to the node where cache PV is bound
        [runners.kubernetes.affinity]
          [runners.kubernetes.affinity.node_affinity]
            [runners.kubernetes.affinity.node_affinity.required_during_scheduling_ignored_during_execution]
              [[runners.kubernetes.affinity.node_affinity.required_during_scheduling_ignored_during_execution.node_selector_terms]]
                [[runners.kubernetes.affinity.node_affinity.required_during_scheduling_ignored_during_execution.node_selector_terms.match_expressions]]
                  key = "kubernetes.io/hostname"
                  operator = "In"
                  values = ["YOUR_NODE_NAME"]  # Replace with node where PVC is bound
```

3. **Find the node where PVC is bound**:
```bash
# Get PV name
PV_NAME=$(kubectl get pvc gitlab-runner-cache -o jsonpath='{.spec.volumeName}')

# Get node where PV is located
kubectl get pv $PV_NAME -o jsonpath='{.spec.nodeAffinity.required.nodeSelectorTerms[0].matchExpressions[0].values[0]}'
```

### Pros & Cons
- ✅ Simplest setup
- ✅ Fast local disk performance
- ✅ No additional components
- ❌ All jobs run on one node only
- ❌ Not true multi-node sharing

---

## Comparison Matrix

| Solution | Setup Complexity | Multi-Node | HA | Performance | Resources |
|----------|------------------|------------|----|--------------  |-----------|
| **External NFS** | Low | ✅ | Depends on NFS | Medium | Low |
| **K8s NFS Pod** | Medium | ✅ | ❌ | Medium | Low |
| **Longhorn** | High | ✅ | ✅ | Good | High |
| **Single Node** | Very Low | ❌ | ❌ | Excellent | Very Low |

## Recommendation

1. **For 3-node cluster with existing NFS**: Use **Option 1 (External NFS)**
2. **For 3-node cluster without NFS**: Use **Option 2 (K8s NFS Pod)**
3. **For production with budget**: Use **Option 3 (Longhorn)**
4. **For development/testing**: Use **Option 4 (Single Node)**

## Testing Multi-Node Cache

After setup, verify multi-node cache sharing:

```bash
# 1. Run the verification script
./verify-cache.sh

# 2. Check PVC access mode
kubectl get pvc gitlab-runner-cache -o jsonpath='{.spec.accessModes[0]}'
# Should output: ReadWriteMany

# 3. Deploy test pods on different nodes
kubectl run test-cache-1 --image=alpine --command -- sh -c "echo 'Node 1' > /cache/test.txt && sleep 3600" --overrides='{"spec":{"volumes":[{"name":"cache","persistentVolumeClaim":{"claimName":"gitlab-runner-cache"}}],"containers":[{"name":"test-cache-1","volumeMounts":[{"name":"cache","mountPath":"/cache"}]}]}}'

kubectl run test-cache-2 --image=alpine --command -- sh -c "cat /cache/test.txt && sleep 3600" --overrides='{"spec":{"volumes":[{"name":"cache","persistentVolumeClaim":{"claimName":"gitlab-runner-cache"}}],"containers":[{"name":"test-cache-2","volumeMounts":[{"name":"cache","mountPath":"/cache"}]}]}}'

# 4. Check if both pods can access same cache
kubectl logs test-cache-2
# Should output: Node 1

# 5. Cleanup
kubectl delete pod test-cache-1 test-cache-2
```

## Next Steps

1. Choose the option that best fits your requirements
2. Follow the setup steps for your chosen option
3. Update `gitlab-runner-cache-pvc.yaml` accordingly
4. Run `./setup-nfs-cache.sh` to complete installation
5. Test with the example pipeline

For questions or issues, see the main [README.md](README.md).
