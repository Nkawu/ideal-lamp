# External NFS Server Setup Guide

This guide shows you how to configure GitLab Runner cache using an external NFS server for true multi-node shared access across your 3-node cluster.

## Prerequisites

- ✅ External NFS server accessible from all Kubernetes nodes
- ✅ NFS client packages installed on all Kubernetes nodes
- ✅ Network connectivity between Kubernetes nodes and NFS server

## Step 1: Configure NFS Server

### On Your NFS Server Machine

1. **Install NFS server** (if not already installed):

```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install -y nfs-kernel-server

# CentOS/RHEL
sudo yum install -y nfs-utils
sudo systemctl enable nfs-server
sudo systemctl start nfs-server
```

2. **Create the export directory**:

```bash
# Create directory for GitLab Runner cache
sudo mkdir -p /exports/gitlab-runner-cache

# Set permissions (allow all pods to write)
sudo chown -R nobody:nogroup /exports/gitlab-runner-cache
sudo chmod -R 777 /exports/gitlab-runner-cache
```

3. **Configure NFS exports**:

```bash
# Edit /etc/exports
sudo nano /etc/exports

# Add this line (replace with your Kubernetes subnet):
/exports/gitlab-runner-cache 192.168.1.0/24(rw,sync,no_subtree_check,no_root_squash)

# Or allow specific nodes:
/exports/gitlab-runner-cache 192.168.1.10(rw,sync,no_subtree_check,no_root_squash)
/exports/gitlab-runner-cache 192.168.1.11(rw,sync,no_subtree_check,no_root_squash)
/exports/gitlab-runner-cache 192.168.1.12(rw,sync,no_subtree_check,no_root_squash)
```

**NFS Export Options Explained:**
- `rw`: Read-write access
- `sync`: Write changes to disk before responding (safer but slower)
- `no_subtree_check`: Disable subtree checking (improves reliability)
- `no_root_squash`: Allow root users to access as root (required for Kubernetes)

4. **Apply the exports**:

```bash
# Reload NFS exports
sudo exportfs -ra

# Verify exports
sudo exportfs -v
# Should show: /exports/gitlab-runner-cache 192.168.1.0/24(rw,sync,...)

# Restart NFS server
sudo systemctl restart nfs-kernel-server  # Ubuntu/Debian
# OR
sudo systemctl restart nfs-server  # CentOS/RHEL
```

5. **Configure firewall** (if enabled):

```bash
# Ubuntu/Debian with ufw
sudo ufw allow from 192.168.1.0/24 to any port nfs

# CentOS/RHEL with firewalld
sudo firewall-cmd --permanent --add-service=nfs
sudo firewall-cmd --permanent --add-service=mountd
sudo firewall-cmd --permanent --add-service=rpc-bind
sudo firewall-cmd --reload
```

## Step 2: Configure Kubernetes Nodes

### On Each Kubernetes Node

Install NFS client packages:

```bash
# Ubuntu/Debian
sudo apt-get install -y nfs-common

# CentOS/RHEL
sudo yum install -y nfs-utils
```

### Test NFS Mount (Optional but Recommended)

From any Kubernetes node:

```bash
# Test mount
sudo mkdir -p /mnt/test-nfs
sudo mount -t nfs NFS_SERVER_IP:/exports/gitlab-runner-cache /mnt/test-nfs

# Verify
df -h | grep nfs
ls -la /mnt/test-nfs

# Test write
echo "test" | sudo tee /mnt/test-nfs/test.txt
cat /mnt/test-nfs/test.txt

# Unmount
sudo umount /mnt/test-nfs
```

## Step 3: Configure GitLab Runner PVC

1. **Edit the PVC configuration**:

```bash
cd /path/to/k8s
nano gitlab-runner-cache-pvc.yaml
```

2. **Update NFS server settings**:

Find these lines and replace:
```yaml
nfs:
  server: NFS_SERVER_IP  # Replace with your NFS server IP
  path: /gitlab-runner-cache  # Replace with your export path
```

For example:
```yaml
nfs:
  server: 192.168.1.100
  path: /exports/gitlab-runner-cache
```

3. **Quick sed command** (alternative):

```bash
# Replace NFS_SERVER_IP with your actual IP
sed -i 's/NFS_SERVER_IP/192.168.1.100/' gitlab-runner-cache-pvc.yaml

# Update path if different
sed -i 's|/gitlab-runner-cache|/exports/gitlab-runner-cache|' gitlab-runner-cache-pvc.yaml
```

## Step 4: Update GitLab Runner Configuration

1. **Edit values.yaml**:

```bash
nano values.yaml
```

2. **Update GitLab URL and registration token**:

```yaml
gitlabUrl: https://your-gitlab-instance.com/
runnerRegistrationToken: "your-registration-token-here"
```

Get your registration token from:
**GitLab → Settings → CI/CD → Runners → "New project runner"**

## Step 5: Deploy Everything

### Option A: Automated Setup (Recommended)

```bash
./setup-nfs-cache.sh
```

The script will:
- ✅ Verify NFS configuration
- ✅ Check MicroK8s and Helm
- ✅ Deploy PV and PVC
- ✅ Install GitLab Runner
- ✅ Show deployment status

### Option B: Manual Setup

```bash
# 1. Deploy PV and PVC
kubectl apply -f gitlab-runner-cache-pvc.yaml

# 2. Verify PVC is bound
kubectl get pvc gitlab-runner-cache
# Should show: STATUS=Bound, ACCESS MODES=RWX

# 3. Check PV details
kubectl get pv

# 4. Add GitLab Helm repo
helm repo add gitlab https://charts.gitlab.io
helm repo update

# 5. Install GitLab Runner
helm install gitlab-runner gitlab/gitlab-runner \
  --version 0.82.0 \
  -f values.yaml

# 6. Verify runner is running
kubectl get pods -l app=gitlab-runner
kubectl logs -l app=gitlab-runner
```

## Step 6: Verify Installation

Run the verification script:

```bash
./verify-cache.sh
```

Expected output:
```
[TEST] Checking storage classes...
[✓] Found 1 storage class(es)

[TEST] Checking GitLab Runner cache PVC...
[✓] PVC is bound
    Access Mode: ReadWriteMany
    Storage Class:
    Capacity: 10Gi
[✓] PVC supports ReadWriteMany (multi-node shared access)

[TEST] Checking Persistent Volume...
[✓] Persistent Volume: gitlab-runner-cache-pv
    Status: Bound

...

[✓] Tests Passed: 7/7
```

## Step 7: Test Multi-Node Cache

1. **Deploy test pods on different nodes**:

```bash
# Create test pod 1
cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: Pod
metadata:
  name: cache-test-writer
spec:
  containers:
  - name: test
    image: alpine
    command: ['sh', '-c', 'echo "Hello from $(hostname) at $(date)" > /cache/test.txt && cat /cache/test.txt && sleep 3600']
    volumeMounts:
    - name: cache
      mountPath: /cache
  volumes:
  - name: cache
    persistentVolumeClaim:
      claimName: gitlab-runner-cache
  nodeSelector:
    kubernetes.io/hostname: node1  # Replace with your node name
EOF

# Create test pod 2 on different node
cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: Pod
metadata:
  name: cache-test-reader
spec:
  containers:
  - name: test
    image: alpine
    command: ['sh', '-c', 'sleep 5 && cat /cache/test.txt && sleep 3600']
    volumeMounts:
    - name: cache
      mountPath: /cache
  volumes:
  - name: cache
    persistentVolumeClaim:
      claimName: gitlab-runner-cache
  nodeSelector:
    kubernetes.io/hostname: node2  # Replace with different node
EOF
```

2. **Check logs**:

```bash
# Wait a moment, then check logs
kubectl logs cache-test-writer
kubectl logs cache-test-reader

# Both should show the same content
```

3. **Cleanup**:

```bash
kubectl delete pod cache-test-writer cache-test-reader
```

## Troubleshooting

### PVC Stuck in Pending

```bash
# Check PVC events
kubectl describe pvc gitlab-runner-cache

# Common issues:
# 1. PV not created - check gitlab-runner-cache-pvc.yaml
# 2. Label mismatch - ensure labels match between PV and PVC
```

### PV Shows as Available (Not Bound)

```bash
# Check label selectors
kubectl get pv gitlab-runner-cache-pv -o yaml | grep -A5 labels

kubectl get pvc gitlab-runner-cache -o yaml | grep -A5 selector

# Labels must match exactly
```

### Mount Fails with "access denied" or "permission denied"

```bash
# On NFS server, check exports
sudo exportfs -v

# Verify no_root_squash is set
# Add it if missing:
sudo nano /etc/exports
# Change to: /exports/gitlab-runner-cache 192.168.1.0/24(rw,sync,no_subtree_check,no_root_squash)

sudo exportfs -ra
```

### Mount Fails with "connection refused"

```bash
# Test NFS connectivity from a Kubernetes node
showmount -e NFS_SERVER_IP

# If this fails, check:
# 1. Firewall on NFS server
# 2. NFS server is running: sudo systemctl status nfs-server
# 3. Network connectivity: ping NFS_SERVER_IP
```

### Pods Can't Write to Cache

```bash
# Check NFS directory permissions on NFS server
ls -la /exports/gitlab-runner-cache

# Should be world-writable
sudo chmod 777 /exports/gitlab-runner-cache
```

### Performance Issues

```bash
# Consider using NFSv4 (default in the PVC)
# If using NFSv3, update mountOptions in gitlab-runner-cache-pvc.yaml:
mountOptions:
  - nfsvers=3
  - hard
  - timeo=600
  - retrans=2
```

## Configuration Reference

### PV Configuration

```yaml
spec:
  nfs:
    server: 192.168.1.100  # Your NFS server IP
    path: /exports/gitlab-runner-cache  # Your export path
  mountOptions:
    - nfsvers=4.1  # NFS version (4.1 recommended)
    - hard  # Hard mount (don't give up on errors)
    - timeo=600  # Timeout in deciseconds (60 seconds)
    - retrans=2  # Number of retransmissions
```

### Mount Options Explained

- `nfsvers=4.1`: Use NFSv4.1 protocol (better performance and security)
- `hard`: Keep trying on errors (recommended for data integrity)
- `soft`: Give up after timeout (use only for non-critical data)
- `timeo=600`: Wait 60 seconds before timeout
- `retrans=2`: Retry 2 times before giving up

## Next Steps

1. **Copy example pipeline** to your GitLab repository:
   ```bash
   cp .gitlab-ci.yml /path/to/your/repo/
   cd /path/to/your/repo/
   git add .gitlab-ci.yml
   git commit -m "Add GitLab CI with shared cache"
   git push
   ```

2. **Monitor cache usage**:
   ```bash
   # From NFS server
   du -sh /exports/gitlab-runner-cache/*

   # From a job pod
   kubectl exec -it <job-pod-name> -- df -h /cache
   ```

3. **View cache contents**:
   ```bash
   # From NFS server
   ls -lh /exports/gitlab-runner-cache/

   # From a job pod
   kubectl exec -it <job-pod-name> -- ls -lh /cache/
   ```

## Benefits of External NFS

✅ **True multi-node sharing** - Jobs run on any of your 3 nodes
✅ **Concurrent access** - Multiple jobs access cache simultaneously
✅ **Centralized management** - Cache visible and manageable from NFS server
✅ **Independent lifecycle** - Cache persists even if cluster is destroyed
✅ **Easy backup** - Standard filesystem backup tools work

## Performance Tips

1. **Use NFSv4.1** for better performance
2. **Use `async` instead of `sync`** if data loss on crash is acceptable (faster)
3. **Enable caching** on NFS clients
4. **Use SSD storage** on NFS server for cache directory
5. **Ensure good network** between nodes and NFS server (1Gbps minimum)

For more information, see the main [README.md](README.md).
