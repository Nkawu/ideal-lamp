# GitLab Runner with Cache - Quick Start Guide

Complete setup for GitLab Runner on MicroK8s with persistent cache storage.

## 🚀 One-Command Setup

```bash
# Run automated setup
./setup-nfs-cache.sh
```

## 📋 Prerequisites Checklist

- [ ] MicroK8s cluster running (single or multi-node)
- [ ] Helm 3 installed
- [ ] kubectl configured
- [ ] GitLab instance accessible
- [ ] Runner registration token from GitLab
- [ ] NFS addon available (automatically enabled by setup script)

## 🔧 Configuration Steps

### 1. Update Configuration

Edit [`values.yaml`](values.yaml):

```yaml
gitlabUrl: https://your-gitlab-instance.com/
runnerRegistrationToken: "your-token-here"
```

Get your registration token from:
**GitLab → Settings → CI/CD → Runners → "New project runner"**

### 2. Verify Storage

```bash
# Check available storage classes
kubectl get storageclass

# The setup script will automatically enable NFS addon
# To manually enable NFS:
microk8s enable community
microk8s enable nfs
```

### 3. Deploy Everything

**Option A: Automated (Recommended)**

```bash
./setup-nfs-cache.sh
```

**Option B: Manual**

```bash
# 1. Add Helm repo
helm repo add gitlab https://charts.gitlab.io
helm repo update

# 2. Create PVC
kubectl apply -f gitlab-runner-cache-pvc.yaml

# 3. Install runner
helm install gitlab-runner gitlab/gitlab-runner \
  --version 0.82.0 \
  -f values.yaml
```

### 4. Verify Installation

```bash
./verify-cache.sh
```

Expected output: **9/9 tests passed** ✓

### 5. Test with Pipeline

```bash
# Copy example pipeline to your repo
cp .gitlab-ci.yml /path/to/your/repo/
cd /path/to/your/repo/
git add .gitlab-ci.yml
git commit -m "Add GitLab CI with shared cache"
git push
```

## 📁 File Overview

| File | Purpose |
|------|---------|
| [`values.yaml`](values.yaml) | Helm chart configuration for GitLab Runner |
| [`gitlab-runner-cache-pvc.yaml`](gitlab-runner-cache-pvc.yaml) | PVC manifest for NFS shared cache |
| [`setup-nfs-cache.sh`](setup-nfs-cache.sh) | Automated setup script |
| [`verify-cache.sh`](verify-cache.sh) | Verification and testing script |
| [`.gitlab-ci.yml`](.gitlab-ci.yml) | Example pipeline demonstrating cache usage |
| [`README.md`](README.md) | Complete documentation |

## ✅ Verification Checklist

After deployment, verify:

- [ ] Storage class exists: `kubectl get storageclass`
- [ ] PVC is bound: `kubectl get pvc gitlab-runner-cache`
- [ ] PVC status shows `Bound`
- [ ] Runner pod running: `kubectl get pods -l app=gitlab-runner`
- [ ] Runner registered in GitLab: Check GitLab UI
- [ ] Cache accessible: `./verify-cache.sh`

## 🔍 Testing Cache

The example pipeline ([`.gitlab-ci.yml`](.gitlab-ci.yml)) demonstrates:

1. **Build counter** - Increments on each run
2. **Build history** - Logs all builds
3. **Parallel access** - Multiple jobs reading/writing simultaneously
4. **Persistence** - Data survives across pipeline runs

Watch it work:

```bash
# View cache contents from any job pod
kubectl get pods  # Find a job pod
kubectl exec -it <job-pod-name> -- sh
ls -lh /cache/
cat /cache/build-counter.txt
cat /cache/build-history.log
```

## 🎯 Key Features

- ✅ **NFS-backed shared storage** - Multi-node cache access with ReadWriteMany
- ✅ **No external services** - Uses built-in MicroK8s NFS addon
- ✅ **Persistent** - Cache survives pod restarts
- ✅ **Simple setup** - Automated NFS provisioning
- ✅ **Multi-node support** - Jobs can run on any node and share cache
- ✅ **Concurrent access** - Multiple jobs can read/write simultaneously

## 🛠️ Common Commands

```bash
# Check runner status
kubectl get pods -l app=gitlab-runner
kubectl logs -l app=gitlab-runner

# Check cache PVC
kubectl get pvc gitlab-runner-cache
kubectl describe pvc gitlab-runner-cache

# Check NFS server
kubectl get pods -n nfs-server-provisioner

# Inspect cache contents
kubectl exec -it <runner-pod-name> -- ls -lh /cache/

# Upgrade runner
helm upgrade gitlab-runner gitlab/gitlab-runner \
  --version 0.82.0 \
  -f values.yaml

# Uninstall everything
helm uninstall gitlab-runner
kubectl delete -f gitlab-runner-cache-pvc.yaml
```

## 🐛 Troubleshooting

### PVC Won't Bind

```bash
# Check NFS storage is available
kubectl get storageclass nfs-csi

# Enable NFS if needed
microk8s enable community
microk8s enable nfs

# Check NFS provisioner status
kubectl get pods -n nfs-server-provisioner

# Check PVC events
kubectl describe pvc gitlab-runner-cache

# Check PV provisioning
kubectl get pv
```

### Runner Not Registering

```bash
# Check runner logs
kubectl logs -l app=gitlab-runner

# Common issues:
# - Wrong GitLab URL in values.yaml
# - Invalid registration token
# - Network connectivity to GitLab
```

### Cache Not Working in Jobs

```bash
# Verify PVC is mounted in job pods
kubectl get pods  # Find a job pod
kubectl describe pod <job-pod-name>

# Should see volume mount at /cache
# Should see PVC: gitlab-runner-cache
```

## 📚 Additional Resources

- Full documentation: [`README.md`](README.md)
- GitLab Runner docs: https://docs.gitlab.com/runner/
- MicroK8s NFS addon: https://microk8s.io/docs/addon-nfs

## 💡 Tips

1. **Storage location**: Cache stored in NFS server pod in `nfs-server-provisioner` namespace
2. **Cache size**: Default 10Gi, adjust in `gitlab-runner-cache-pvc.yaml`
3. **Runner scaling**: Increase `concurrent` in `values.yaml` for more parallel jobs
4. **Cache cleanup**: Use the `cleanup_cache` job in pipeline or manually delete files
5. **Monitoring**: Check cache size with `du -sh /cache` from any job pod
6. **Multi-node access**: Jobs automatically scheduled across all 3 nodes with shared cache
7. **NFS performance**: Slightly slower than local disk but enables true multi-node sharing

## 🎉 Success Criteria

You'll know it's working when:

1. Pipeline runs successfully
2. Build counter increments on each run
3. Multiple jobs access cache simultaneously
4. Cache persists between pipeline runs
5. No cache-related errors in job logs

---

**Need help?** See the full [`README.md`](README.md) for detailed documentation.
