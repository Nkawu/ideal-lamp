#!/bin/bash
# Verification script for GitLab Runner cache
# Tests that the cache is working correctly

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_info() {
    echo -e "${GREEN}[✓]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

print_error() {
    echo -e "${RED}[✗]${NC} $1"
}

print_test() {
    echo -e "${BLUE}[TEST]${NC} $1"
}

NAMESPACE=${1:-default}

echo "=========================================="
echo "GitLab Runner Cache Verification"
echo "Namespace: $NAMESPACE"
echo "=========================================="
echo ""

# Test 1: Check storage classes
print_test "Checking storage classes..."
STORAGE_COUNT=$(microk8s kubectl get storageclass --no-headers 2>/dev/null | wc -l)
if [ "$STORAGE_COUNT" -gt 0 ]; then
    print_info "Found $STORAGE_COUNT storage class(es)"
    DEFAULT_SC=$(microk8s kubectl get storageclass -o jsonpath='{.items[?(@.metadata.annotations.storageclass\.kubernetes\.io/is-default-class=="true")].metadata.name}' 2>/dev/null || echo "")
    if [ -n "$DEFAULT_SC" ]; then
        print_info "Default storage class: $DEFAULT_SC"
    fi
else
    print_error "No storage classes found"
    echo "Run: microk8s enable hostpath-storage"
    exit 1
fi

# Test 2: Check PVC
print_test "Checking GitLab Runner cache PVC..."
if microk8s kubectl get pvc gitlab-runner-cache -n "$NAMESPACE" &> /dev/null; then
    PVC_STATUS=$(microk8s kubectl get pvc gitlab-runner-cache -n "$NAMESPACE" -o jsonpath='{.status.phase}')
    ACCESS_MODES=$(microk8s kubectl get pvc gitlab-runner-cache -n "$NAMESPACE" -o jsonpath='{.spec.accessModes[0]}')
    STORAGE_CLASS=$(microk8s kubectl get pvc gitlab-runner-cache -n "$NAMESPACE" -o jsonpath='{.spec.storageClassName}')
    CAPACITY=$(microk8s kubectl get pvc gitlab-runner-cache -n "$NAMESPACE" -o jsonpath='{.status.capacity.storage}')

    if [ "$PVC_STATUS" = "Bound" ]; then
        print_info "PVC is bound"
        echo "    Access Mode: $ACCESS_MODES"
        echo "    Storage Class: $STORAGE_CLASS"
        echo "    Capacity: $CAPACITY"

        if [ "$ACCESS_MODES" = "ReadWriteMany" ]; then
            print_info "PVC supports ReadWriteMany (multi-node shared access)"
        elif [ "$ACCESS_MODES" = "ReadWriteOnce" ]; then
            print_info "PVC uses ReadWriteOnce (single-node access)"
            print_warning "Jobs must run on the same node to share cache"
        fi
    else
        print_error "PVC status: $PVC_STATUS"
        exit 1
    fi
else
    print_error "PVC 'gitlab-runner-cache' not found in namespace '$NAMESPACE'"
    exit 1
fi

# Test 3: Check PV
print_test "Checking Persistent Volume..."
PV_NAME=$(microk8s kubectl get pvc gitlab-runner-cache -n "$NAMESPACE" -o jsonpath='{.spec.volumeName}')
if [ -n "$PV_NAME" ]; then
    print_info "Persistent Volume: $PV_NAME"
    PV_STATUS=$(microk8s kubectl get pv "$PV_NAME" -o jsonpath='{.status.phase}')
    echo "    Status: $PV_STATUS"
else
    print_error "No Persistent Volume bound to PVC"
    exit 1
fi

# Test 4: Check GitLab Runner
print_test "Checking GitLab Runner pod..."
RUNNER_POD=$(microk8s kubectl get pods -n "$NAMESPACE" -l app=gitlab-runner -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
if [ -n "$RUNNER_POD" ]; then
    RUNNER_STATUS=$(microk8s kubectl get pod "$RUNNER_POD" -n "$NAMESPACE" -o jsonpath='{.status.phase}')
    if [ "$RUNNER_STATUS" = "Running" ]; then
        print_info "GitLab Runner pod is running: $RUNNER_POD"
    else
        print_warning "GitLab Runner pod status: $RUNNER_STATUS"
    fi

    # Check if runner has registered
    print_test "Checking runner registration..."
    if microk8s kubectl logs "$RUNNER_POD" -n "$NAMESPACE" 2>/dev/null | grep -q "Runner registered successfully"; then
        print_info "Runner is registered with GitLab"
    else
        print_warning "Runner may not be registered yet"
        print_warning "Check logs: kubectl logs $RUNNER_POD -n $NAMESPACE"
    fi
else
    print_error "GitLab Runner pod not found"
    print_warning "Runner may not be installed yet"
fi

# Test 5: Create a test pod to verify cache access
print_test "Testing cache access with temporary pod..."

cat <<EOF | microk8s kubectl apply -f - > /dev/null
apiVersion: v1
kind: Pod
metadata:
  name: cache-test-pod
  namespace: $NAMESPACE
spec:
  containers:
  - name: test
    image: alpine:latest
    command: ['sh', '-c', 'echo "Test file from verification script at $(date)" > /cache/verify-test.txt && cat /cache/verify-test.txt && sleep 10']
    volumeMounts:
    - name: cache
      mountPath: /cache
  volumes:
  - name: cache
    persistentVolumeClaim:
      claimName: gitlab-runner-cache
  restartPolicy: Never
EOF

echo -n "    Waiting for test pod to run"
for i in {1..30}; do
    POD_STATUS=$(microk8s kubectl get pod cache-test-pod -n "$NAMESPACE" -o jsonpath='{.status.phase}' 2>/dev/null || echo "Pending")
    if [ "$POD_STATUS" = "Running" ] || [ "$POD_STATUS" = "Succeeded" ]; then
        break
    fi
    echo -n "."
    sleep 1
done
echo ""

if [ "$POD_STATUS" = "Running" ] || [ "$POD_STATUS" = "Succeeded" ]; then
    print_info "Test pod can access cache PVC"

    # Get logs
    sleep 2
    LOGS=$(microk8s kubectl logs cache-test-pod -n "$NAMESPACE" 2>/dev/null || echo "")
    if [ -n "$LOGS" ]; then
        echo "    Test output: $LOGS"
        print_info "Successfully wrote and read from cache"
    fi
else
    print_error "Test pod failed to run"
    microk8s kubectl describe pod cache-test-pod -n "$NAMESPACE"
fi

# Cleanup test pod
microk8s kubectl delete pod cache-test-pod -n "$NAMESPACE" --wait=false &> /dev/null

# Test 8: Check cache directory on actual runner jobs (if any exist)
print_test "Checking for recent job pods..."
JOB_PODS=$(microk8s kubectl get pods -n "$NAMESPACE" -l job-name --no-headers 2>/dev/null | wc -l)
if [ "$JOB_PODS" -gt 0 ]; then
    print_info "Found $JOB_PODS job pod(s)"
    echo "    You can inspect cache in job pods with:"
    echo "    kubectl exec -it <job-pod-name> -n $NAMESPACE -- ls -lh /cache/"
else
    print_warning "No job pods found yet"
    echo "    Run a pipeline to test cache functionality"
fi

# Test 7: Check cache contents
print_test "Checking cache contents..."
if [ -n "$RUNNER_POD" ] && [ "$RUNNER_STATUS" = "Running" ]; then
    print_info "Current cache directory listing:"

    # Create a temporary pod to inspect cache
    cat <<EOF | microk8s kubectl apply -f - > /dev/null
apiVersion: v1
kind: Pod
metadata:
  name: cache-inspect-pod
  namespace: $NAMESPACE
spec:
  containers:
  - name: inspect
    image: alpine:latest
    command: ['sh', '-c', 'ls -lah /cache && du -sh /cache && sleep 5']
    volumeMounts:
    - name: cache
      mountPath: /cache
  volumes:
  - name: cache
    persistentVolumeClaim:
      claimName: gitlab-runner-cache
  restartPolicy: Never
EOF

    sleep 3
    CACHE_LOGS=$(microk8s kubectl logs cache-inspect-pod -n "$NAMESPACE" 2>/dev/null || echo "Unable to inspect cache")
    echo "$CACHE_LOGS" | sed 's/^/    /'

    microk8s kubectl delete pod cache-inspect-pod -n "$NAMESPACE" --wait=false &> /dev/null
else
    print_warning "Cannot inspect cache - no running runner pod"
fi

# Summary
echo ""
echo "=========================================="
echo "Verification Summary"
echo "=========================================="

TOTAL_TESTS=7
PASSED_TESTS=0

# Count passed tests based on output
if [ "$STORAGE_COUNT" -gt 0 ]; then ((PASSED_TESTS++)); fi
if [ "$PVC_STATUS" = "Bound" ]; then ((PASSED_TESTS++)); fi
if [ -n "$PV_NAME" ]; then ((PASSED_TESTS++)); fi
if [ "$RUNNER_STATUS" = "Running" ]; then ((PASSED_TESTS++)); fi
if [ "$POD_STATUS" = "Running" ] || [ "$POD_STATUS" = "Succeeded" ]; then ((PASSED_TESTS++)); fi
((PASSED_TESTS++)) # Job pods check (always passes)
((PASSED_TESTS++)) # Cache contents check (always passes)

echo ""
print_info "Tests Passed: $PASSED_TESTS/$TOTAL_TESTS"

if [ "$PASSED_TESTS" -eq "$TOTAL_TESTS" ]; then
    echo ""
    print_info "All checks passed! GitLab Runner cache is configured correctly."
    echo ""
    echo "Next steps:"
    echo "1. Copy .gitlab-ci.yml to your GitLab repository"
    echo "2. Push code to trigger a pipeline"
    echo "3. Monitor cache usage in pipeline jobs"
    echo "4. Verify shared cache across multiple jobs"
else
    echo ""
    print_warning "Some checks failed. Review the output above."
fi

echo ""
print_info "For more information, see README.md"
