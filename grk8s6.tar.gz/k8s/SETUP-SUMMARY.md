# GitLab Runner with External NFS Cache - Setup Summary

## Configuration Overview

Your GitLab Runner is now configured to use an **external NFS server** for multi-node cache sharing across your 3-node MicroK8s cluster.

## What You Need to Do

### 1. Configure Your NFS Server

**On your NFS server machine:**

```bash
# Create export directory
sudo mkdir -p /exports/gitlab-runner-cache
sudo chmod 777 /exports/gitlab-runner-cache

# Add to /etc/exports
echo "/exports/gitlab-runner-cache 192.168.1.0/24(rw,sync,no_subtree_check,no_root_squash)" | sudo tee -a /etc/exports

# Apply exports
sudo exportfs -ra
sudo systemctl restart nfs-kernel-server
```

### 2. Configure Kubernetes Nodes

**On each of your 3 Kubernetes nodes:**

```bash
# Install NFS client
sudo apt-get install -y nfs-common
```

### 3. Update Configuration Files

```bash
cd /path/to/k8s

# Update NFS server IP in PVC (replace with your NFS server IP)
sed -i 's/NFS_SERVER_IP/192.168.1.100/' gitlab-runner-cache-pvc.yaml

# Update GitLab configuration
nano values.yaml
# Set: gitlabUrl and runnerRegistrationToken
```

### 4. Deploy Everything

```bash
# Run automated setup
./setup-nfs-cache.sh

# OR manual setup
kubectl apply -f gitlab-runner-cache-pvc.yaml
helm repo add gitlab https://charts.gitlab.io
helm install gitlab-runner gitlab/gitlab-runner --version 0.82.0 -f values.yaml
```

### 5. Verify

```bash
# Run verification script
./verify-cache.sh

# Should show:
# - PVC Status: Bound
# - Access Mode: ReadWriteMany
# - Tests Passed: 7/7
```

## Files Configured

| File | Purpose | Changes Made |
|------|---------|--------------|
| `gitlab-runner-cache-pvc.yaml` | PV/PVC for cache | Now uses external NFS with RWX |
| `setup-nfs-cache.sh` | Automated setup | Validates NFS configuration |
| `values.yaml` | GitLab Runner config | No changes (already configured) |

## Architecture

```
┌─────────────────────────────────────────────────┐
│                3-Node MicroK8s Cluster          │
│                                                 │
│  ┌─────────┐    ┌─────────┐    ┌─────────┐   │
│  │ Node 1  │    │ Node 2  │    │ Node 3  │   │
│  │         │    │         │    │         │   │
│  │  Job    │    │  Job    │    │  Job    │   │
│  │  Pods   │    │  Pods   │    │  Pods   │   │
│  └────┬────┘    └────┬────┘    └────┬────┘   │
│       │              │              │         │
│       └──────────────┼──────────────┘         │
│                      │                        │
└──────────────────────┼────────────────────────┘
                       │
                       │ NFS mount (ReadWriteMany)
                       │
              ┌────────▼────────┐
              │   External NFS   │
              │      Server      │
              │                  │
              │  /exports/       │
              │  gitlab-runner-  │
              │  cache/          │
              └──────────────────┘
```

## Benefits

✅ **Multi-node sharing** - Jobs run on any of 3 nodes
✅ **Concurrent access** - Multiple jobs access cache simultaneously
✅ **Persistent** - Cache survives cluster restarts
✅ **Centralized** - Manage cache from NFS server
✅ **Production-ready** - Standard NFS protocol

## Quick Reference

### Check Cache Status
```bash
# From Kubernetes
kubectl get pvc gitlab-runner-cache -n gitlab
kubectl get pv

# From NFS server
du -sh /exports/gitlab-runner-cache/
ls -lh /exports/gitlab-runner-cache/
```

### View Cache in Job
```bash
# Find a job pod
kubectl get pods

# Exec into it
kubectl exec -it <job-pod-name> -- sh
ls -lh /cache/
cat /cache/build-counter.txt
```

### Monitor GitLab Runner
```bash
kubectl get pods -l app=gitlab-runner
kubectl logs -l app=gitlab-runner
```

## Troubleshooting Quick Fixes

### PVC won't bind
```bash
# Check PVC was configured
grep "server:" gitlab-runner-cache-pvc.yaml
# Should NOT show "NFS_SERVER_IP"

# Test NFS from a node
showmount -e YOUR_NFS_SERVER_IP
```

### Mount permission denied
```bash
# On NFS server - make directory writable
sudo chmod 777 /exports/gitlab-runner-cache
```

### Can't reach NFS server
```bash
# On NFS server - check firewall
sudo ufw allow from 192.168.1.0/24 to any port nfs
```

## Documentation

- **Detailed NFS Setup**: [EXTERNAL-NFS-SETUP.md](EXTERNAL-NFS-SETUP.md)
- **Full Documentation**: [README.md](README.md)
- **Quick Start**: [QUICKSTART.md](QUICKSTART.md)
- **Alternative Options**: [MULTI-NODE-ALTERNATIVES.md](MULTI-NODE-ALTERNATIVES.md)

## Support

If you encounter issues:
1. Check [EXTERNAL-NFS-SETUP.md](EXTERNAL-NFS-SETUP.md) troubleshooting section
2. Run `./verify-cache.sh` to diagnose problems
3. Review `kubectl describe pvc gitlab-runner-cache` for error events

## Next Steps

1. Deploy your first pipeline with `.gitlab-ci.yml`
2. Monitor cache growth on NFS server
3. Set up regular backups of NFS cache directory
4. Tune NFS mount options for performance if needed

Your multi-node GitLab Runner with shared cache is ready to use!
