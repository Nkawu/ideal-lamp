# Multi-Node Cache Sharing with External NFS

This guide explains how to configure external NFS server for sharing cache across your 3-node cluster.

## Why External NFS?

The default MicroK8s `hostpath` storage uses **ReadWriteOnce (RWO)** which means:
- ❌ Only one node can mount the volume at a time
- ❌ Jobs must run on the same node to share cache

External NFS provides **ReadWriteMany (RWX)** access:
- ✅ True multi-node shared access
- ✅ All 3 nodes can access cache simultaneously
- ✅ Centralized cache management
- ✅ Production-ready solution

## External NFS Server Setup

**Use this if you have an existing NFS server in your network.**

### Prerequisites
- NFS server accessible from all cluster nodes
- NFS share exported and accessible

### Setup Steps

1. **Configure the NFS server** (on your NFS server machine):
```bash
# Example: Export /data/gitlab-cache
# Add to /etc/exports:
/data/gitlab-cache *(rw,sync,no_subtree_check,no_root_squash)

# Restart NFS
sudo exportfs -ra
sudo systemctl restart nfs-kernel-server
```

2. **Update the PV/PVC file** [`gitlab-runner-cache-pv-external-nfs.yaml`](gitlab-runner-cache-pv-external-nfs.yaml):
```bash
# Edit the file and replace:
# - NFS_SERVER_IP with your NFS server IP (e.g., 192.168.1.100)
# - /path/to/export with your NFS export path (e.g., /data/gitlab-cache)

nano gitlab-runner-cache-pv-external-nfs.yaml
```

3. **Deploy the PV and PVC**:
```bash
kubectl apply -f gitlab-runner-cache-pv-external-nfs.yaml
kubectl get pvc gitlab-runner-cache -n gitlab
```

4. **Verify**:
```bash
kubectl get pvc gitlab-runner-cache -n gitlab
# Should show: STATUS=Bound, ACCESS MODES=RWX
```

### Benefits
- ✅ True multi-node shared access across all 3 nodes
- ✅ Centralized cache management
- ✅ Can use existing infrastructure
- ✅ Production-ready with standard NFS protocol
- ✅ Network dependency on reliable NFS server

---

## Testing Multi-Node Cache

After setup, verify multi-node cache sharing:

```bash
# 1. Run the verification script
./verify-cache.sh

# 2. Check PVC access mode
kubectl get pvc gitlab-runner-cache -o jsonpath='{.spec.accessModes[0]}'
# Should output: ReadWriteMany

# 3. Deploy test pods on different nodes
kubectl run test-cache-1 --image=alpine --command -- sh -c "echo 'Node 1' > /cache/test.txt && sleep 3600" --overrides='{"spec":{"volumes":[{"name":"cache","persistentVolumeClaim":{"claimName":"gitlab-runner-cache"}}],"containers":[{"name":"test-cache-1","volumeMounts":[{"name":"cache","mountPath":"/cache"}]}]}}'

kubectl run test-cache-2 --image=alpine --command -- sh -c "cat /cache/test.txt && sleep 3600" --overrides='{"spec":{"volumes":[{"name":"cache","persistentVolumeClaim":{"claimName":"gitlab-runner-cache"}}],"containers":[{"name":"test-cache-2","volumeMounts":[{"name":"cache","mountPath":"/cache"}]}]}}'

# 4. Check if both pods can access same cache
kubectl logs test-cache-2
# Should output: Node 1

# 5. Cleanup
kubectl delete pod test-cache-1 test-cache-2
```

## Next Steps

1. Configure your NFS server following the setup steps above
2. Install NFS client packages on all Kubernetes nodes
3. Update `gitlab-runner-cache-pvc.yaml` with your NFS server IP
4. Run `./setup-nfs-cache.sh` to complete installation
5. Test with the example pipeline

## Additional Documentation

- **Detailed NFS setup**: See [EXTERNAL-NFS-SETUP.md](EXTERNAL-NFS-SETUP.md) for complete instructions
- **Full documentation**: See [README.md](README.md)
- **Quick start guide**: See [QUICKSTART.md](QUICKSTART.md)

For questions or issues, refer to the troubleshooting sections in the documentation above.
