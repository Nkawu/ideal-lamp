#!/bin/bash
# GitLab Runner Cache Setup Script for MicroK8s
# This script automates the setup of storage and GitLab Runner with cache

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if MicroK8s is installed
check_microk8s() {
    print_info "Checking MicroK8s installation..."
    if ! command -v microk8s &> /dev/null; then
        print_error "MicroK8s is not installed. Please install it first."
        exit 1
    fi
    print_info "MicroK8s is installed"
}

# Check if Helm is installed
check_helm() {
    print_info "Checking Helm installation..."

    # Check if helm command exists (either as binary or alias)
    if helm version --short &> /dev/null; then
        HELM_VERSION=$(helm version --short 2>/dev/null || echo "unknown")
        print_info "Helm is available: $HELM_VERSION"
    elif microk8s helm version --short &> /dev/null; then
        HELM_VERSION=$(microk8s helm version --short 2>/dev/null || echo "unknown")
        print_info "Helm is available via MicroK8s: $HELM_VERSION"
        print_warning "Using 'microk8s helm' - you may want to alias: alias helm='microk8s helm'"
    else
        print_error "Helm is not installed. Please install it first."
        print_info "For MicroK8s, you can use: microk8s enable helm3"
        exit 1
    fi
}

# Check storage availability
check_storage() {
    print_info "Checking storage availability..."

    # Check for available storage classes
    STORAGE_CLASSES=$(microk8s kubectl get storageclass --no-headers 2>/dev/null | wc -l)

    if [ "$STORAGE_CLASSES" -eq 0 ]; then
        print_warning "No storage classes found"
        print_info "Checking if hostpath-storage addon is available..."

        if microk8s status | grep -q "hostpath-storage: disabled"; then
            print_info "Enabling hostpath-storage addon..."
            microk8s enable hostpath-storage
            sleep 5
        else
            print_error "No storage available and cannot enable hostpath-storage"
            exit 1
        fi
    fi

    # Verify storage class exists now
    DEFAULT_SC=$(microk8s kubectl get storageclass -o jsonpath='{.items[?(@.metadata.annotations.storageclass\.kubernetes\.io/is-default-class=="true")].metadata.name}' 2>/dev/null || echo "")

    if [ -n "$DEFAULT_SC" ]; then
        print_info "Default storage class available: $DEFAULT_SC"

        # Check if it supports ReadWriteMany
        if microk8s kubectl get storageclass "$DEFAULT_SC" -o jsonpath='{.allowedTopologies}' 2>/dev/null | grep -q "ReadWriteMany"; then
            print_info "Storage class supports ReadWriteMany (multi-node access)"
        else
            print_warning "Storage class uses ReadWriteOnce (single-node access)"
            print_warning "For multi-node cache sharing, consider:"
            print_warning "  1. External NFS server (see gitlab-runner-cache-pv-external-nfs.yaml)"
            print_warning "  2. Manual NFS deployment (see nfs-server-deployment.yaml)"
            print_warning "  3. Other RWX-capable storage (Longhorn, Ceph, etc.)"
        fi
    else
        # If no default, just show available storage classes
        print_info "Available storage classes:"
        microk8s kubectl get storageclass
    fi
}

# Create namespace
create_namespace() {
    NAMESPACE=${1:-gitlab}

    print_info "Checking namespace '$NAMESPACE'..."
    if ! microk8s kubectl get namespace "$NAMESPACE" &> /dev/null; then
        print_info "Creating namespace '$NAMESPACE'..."
        microk8s kubectl create namespace "$NAMESPACE"
    else
        print_info "Namespace '$NAMESPACE' already exists"
    fi
}

# Deploy PVC
deploy_pvc() {
    NAMESPACE=${1:-gitlab}

    print_info "Deploying GitLab Runner cache PVC..."

    # Update namespace in PVC file if needed
    if [ "$NAMESPACE" != "default" ]; then
        print_info "Updating namespace in PVC manifest to '$NAMESPACE'..."
        sed -i.bak "s/namespace: default/namespace: $NAMESPACE/" gitlab-runner-cache-pvc.yaml
    fi

    # Apply PVC
    microk8s kubectl apply -f gitlab-runner-cache-pvc.yaml

    # Wait for PVC to be bound
    print_info "Waiting for PVC to be bound..."
    for i in {1..30}; do
        STATUS=$(microk8s kubectl get pvc gitlab-runner-cache -n "$NAMESPACE" -o jsonpath='{.status.phase}' 2>/dev/null || echo "")
        if [ "$STATUS" = "Bound" ]; then
            print_info "PVC is bound successfully"
            microk8s kubectl get pvc gitlab-runner-cache -n "$NAMESPACE"
            return 0
        fi
        echo -n "."
        sleep 2
    done

    print_error "PVC failed to bind within timeout"
    microk8s kubectl describe pvc gitlab-runner-cache -n "$NAMESPACE"
    exit 1
}

# Add GitLab Helm repo
add_helm_repo() {
    print_info "Adding GitLab Helm repository..."

    if helm repo list | grep -q "^gitlab"; then
        print_info "GitLab repo already added, updating..."
        helm repo update gitlab
    else
        helm repo add gitlab https://charts.gitlab.io
        helm repo update
    fi
}

# Verify PVC configuration for external NFS
verify_pvc_config() {
    print_info "Verifying PVC configuration for external NFS..."

    if [ ! -f "gitlab-runner-cache-pvc.yaml" ]; then
        print_error "gitlab-runner-cache-pvc.yaml not found in current directory"
        exit 1
    fi

    # Check if NFS server IP is set
    if grep -q "server: NFS_SERVER_IP" gitlab-runner-cache-pvc.yaml; then
        print_error "NFS server IP is not configured!"
        echo ""
        print_warning "Please update gitlab-runner-cache-pvc.yaml:"
        echo "  1. Replace 'NFS_SERVER_IP' with your NFS server IP (e.g., 192.168.1.100)"
        echo "  2. Replace '/gitlab-runner-cache' with your NFS export path (if different)"
        echo ""
        print_info "Example: sed -i 's/NFS_SERVER_IP/192.168.1.100/' gitlab-runner-cache-pvc.yaml"
        return 1
    fi

    print_info "NFS configuration appears to be set"
    return 0
}

# Verify values.yaml configuration
verify_values() {
    print_info "Verifying values.yaml configuration..."

    if [ ! -f "values.yaml" ]; then
        print_error "values.yaml not found in current directory"
        exit 1
    fi

    # Check if GitLab URL is set
    if grep -q "gitlabUrl: https://gitlab.example.com/" values.yaml; then
        print_warning "GitLab URL is still set to example.com"
        print_warning "Please update 'gitlabUrl' in values.yaml before installing"
    fi

    # Check if registration token is set
    if grep -q "runnerRegistrationToken: \"YOUR_REGISTRATION_TOKEN_HERE\"" values.yaml; then
        print_warning "Runner registration token is not set"
        print_warning "Please update 'runnerRegistrationToken' in values.yaml before installing"
    fi
}

# Install GitLab Runner
install_runner() {
    NAMESPACE=${1:-gitlab}
    RELEASE_NAME=${2:-gitlab-runner}

    print_info "Installing GitLab Runner..."

    helm install "$RELEASE_NAME" gitlab/gitlab-runner \
        --version 0.82.0 \
        --namespace "$NAMESPACE" \
        -f values.yaml

    print_info "Waiting for runner pod to be ready..."
    sleep 5
    microk8s kubectl wait --for=condition=ready pod -l app=gitlab-runner -n "$NAMESPACE" --timeout=120s || true

    print_info "GitLab Runner installation completed"
    microk8s kubectl get pods -n "$NAMESPACE" -l app=gitlab-runner
}

# Show status
show_status() {
    NAMESPACE=${1:-default}

    echo ""
    print_info "====== Deployment Status ======"

    echo ""
    print_info "Storage Classes:"
    microk8s kubectl get storageclass

    echo ""
    print_info "PVC:"
    microk8s kubectl get pvc -n "$NAMESPACE"

    echo ""
    print_info "PV:"
    microk8s kubectl get pv

    echo ""
    print_info "GitLab Runner:"
    microk8s kubectl get pods -n "$NAMESPACE" -l app=gitlab-runner

    echo ""
    print_info "Runner Logs (last 20 lines):"
    POD=$(microk8s kubectl get pods -n "$NAMESPACE" -l app=gitlab-runner -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
    if [ -n "$POD" ]; then
        microk8s kubectl logs -n "$NAMESPACE" "$POD" --tail=20
    else
        print_warning "No runner pod found"
    fi

    echo ""
    print_info "====== Next Steps ======"
    echo "1. Verify runner is registered in GitLab: Settings > CI/CD > Runners"
    echo "2. Copy .gitlab-ci.yml to your repository"
    echo "3. Push code to trigger a pipeline"
    echo "4. Monitor cache usage: microk8s kubectl exec -it <job-pod> -- ls -lh /cache/"
}

# Main script
main() {
    echo "=========================================="
    echo "GitLab Runner Cache Setup for MicroK8s"
    echo "=========================================="
    echo ""

    # Parse arguments
    NAMESPACE="gitlab"
    RELEASE_NAME="gitlab-runner"
    SKIP_INSTALL=false

    while [[ $# -gt 0 ]]; do
        case $1 in
            -n|--namespace)
                NAMESPACE="$2"
                shift 2
                ;;
            -r|--release)
                RELEASE_NAME="$2"
                shift 2
                ;;
            --nfs-only)
                SKIP_INSTALL=true
                shift
                ;;
            -h|--help)
                echo "Usage: $0 [OPTIONS]"
                echo ""
                echo "Options:"
                echo "  -n, --namespace NAME    Kubernetes namespace (default: gitlab)"
                echo "  -r, --release NAME      Helm release name (default: gitlab-runner)"
                echo "  --nfs-only              Only setup storage, skip runner installation"
                echo "  -h, --help              Show this help message"
                exit 0
                ;;
            *)
                print_error "Unknown option: $1"
                exit 1
                ;;
        esac
    done

    # Run setup steps
    check_microk8s
    check_helm
    check_storage
    create_namespace "$NAMESPACE"

    # Verify NFS configuration before deploying PVC
    if ! verify_pvc_config; then
        print_error "Please configure NFS settings before continuing"
        exit 1
    fi

    deploy_pvc "$NAMESPACE"

    if [ "$SKIP_INSTALL" = false ]; then
        verify_values
        add_helm_repo

        echo ""
        print_warning "About to install GitLab Runner with the following configuration:"
        echo "  Namespace: $NAMESPACE"
        echo "  Release Name: $RELEASE_NAME"
        echo ""
        read -p "Continue with installation? (y/N) " -n 1 -r
        echo

        if [[ $REPLY =~ ^[Yy]$ ]]; then
            install_runner "$NAMESPACE" "$RELEASE_NAME"
            show_status "$NAMESPACE"
        else
            print_info "Installation skipped. You can install manually later with:"
            echo "  helm install $RELEASE_NAME gitlab/gitlab-runner --version 0.82.0 -f values.yaml"
        fi
    else
        print_info "Storage setup completed. Skipping runner installation."
        echo ""
        print_info "To install runner later, run:"
        echo "  helm install $RELEASE_NAME gitlab/gitlab-runner --version 0.82.0 -f values.yaml"
    fi

    echo ""
    print_info "Setup completed successfully!"
}

# Run main
main "$@"
